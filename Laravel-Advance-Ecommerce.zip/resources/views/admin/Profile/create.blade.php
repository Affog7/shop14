@extends('admin.admin_master')

@section('title', 'Admin Profile')

@section('dashboard_content')

@endsection

