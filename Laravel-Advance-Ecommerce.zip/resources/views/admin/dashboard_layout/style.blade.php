<!-- Vendors Style-->

<link rel="stylesheet" href="{{ asset('backend') }}/css/vendors_css.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.css" integrity="sha512-3pIirOrwegjM6erE5gPSwkUzO+3cTjpnV9lexlNZqvupR64iZBnOOTiiLPb9M36zpMScbmUNIcHUqKD47M719g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<!-- Style-->
<link rel="stylesheet" href="{{ asset('backend') }}/css/style.css">
<link rel="stylesheet" href="{{ asset('backend') }}/css/skin_color.css">
