<div class="cart-item product-summary">
    <div class="row">
        <div class="col-xs-4">
            <div class="image"> <a href="detail.html"><img src="{{ asset('frontend') }}/assets/images/cart.jpg"
                        alt=""></a> </div>
        </div>
        <div class="col-xs-7">
            <h3 class="name"><a href="index.php?page-detail">Simple Product</a></h3>
            <div class="price">$600.00</div>
        </div>
        <div class="col-xs-1 action"> <a href="#"><i class="fa fa-trash"></i></a> </div>
    </div>
</div>
<!-- /.cart-item -->
<div class="clearfix"></div>
<hr>
