
  <meta name="keywords">
  <meta name="description" content="Entrez dans le monde de CHANEL et découvrez les toutes dernières créations, les Accessoires de Mode, Lunettes, Parfums &amp; Beauté, Montres &amp; Joaillerie.">
		<meta name="robots" content="index,follow">
		<meta name="robots" content="max-image-preview:large">
		<meta name="referrer" content="always">
		<meta>
		<meta http-equiv="X-UA-Compatible">
		<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
		<meta name="apple-mobile-web-app-capable" content="yes">
		<meta name="geo.region" content="FR">
		<meta name="language" content="fr-FR">
		<meta name="Author" content="CHANEL">
		<meta property="og:site_name" content="CHANEL">
		<meta property="og:title" content="CHANEL Site Officiel : Mode, Parfum, Beauté, Horlogerie, Joaillerie | CHANEL">
		<meta property="og:description" content="Entrez dans le monde de CHANEL et découvrez les toutes dernières créations, les Accessoires de Mode, Lunettes, Parfums &amp; Beauté, Montres &amp; Joaillerie.">
		<meta property="og:type" content="website">
		<meta property="og:image" content="https://www.chanel.com/_ui/responsive/theme-onechanel/assets/media/favicon/192x192.png">
		<meta property="og:site_name" content="CHANEL">
		<meta property="og:url" content="https://www.chanel.com/fr/">
		<meta property="fb:app_id" content="204051566463918">
		<meta name="twitter:card" content="summary_large_image">
		<meta name="twitter:site" content="@chanel">
		<meta name="twitter:creator" content="@chanel">
		<meta name="twitter:domain" content="chanel.com">
		<meta name="twitter:url" content="https://www.chanel.com/fr/">
		<meta name="twitter:maxage" content="720">
		<meta name="twitter:title" content="CHANEL Site Officiel : Mode, Parfum, Beauté, Horlogerie, Joaillerie | CHANEL">
		<meta name="twitter:description" content="Entrez dans le monde de CHANEL et découvrez les toutes dernières créations, les Accessoires de Mode, Lunettes, Parfums &amp; Beauté, Montres &amp; Joaillerie.">
		<meta name="twitter:image" content="https://www.chanel.com/_ui/responsive/theme-onechanel/assets/media/favicon/192x192.png">
		