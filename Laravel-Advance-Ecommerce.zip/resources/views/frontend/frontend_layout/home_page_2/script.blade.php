<script type="text/javascript" id="">window.performance&&window.performance.mark("main_gtm_loaded");</script><script type="text/javascript" id="">function getCookie(c){c+="\x3d";var b=decodeURIComponent(document.cookie);b=b.split(";");for(var d=0;d<b.length;d++){for(var a=b[d];" "==a.charAt(0);)a=a.substring(1);if(0==a.indexOf(c))return a.substring(c.length,a.length)}return""}
    for(var cookieVal=getCookie("segmentsEDM"),list="boutiqueclients-elite-+ boutiqueclients-pvic boutiqueclients-vic boutiqueclients-vvic boutiqueclients-lowpotentials boutiqueclients-topaccessoriesonly boutiqueclients-handbagaspirationals boutiqueclients-highcrossshoppers boutiqueclients-accessoriesrisingstars boutiqueclients-occasionals boutiqueclients-elites boutiqueclients-rtwexplorers boutiqueclients-rtwrecent boutiqueclients-rtwlapsed boutiqueclients-accrecent boutiqueclients-acclapsed boutiqueclients-wfjrec boutiqueclients-wfjlap boutiqueclients-fbboutique boutiqueclients-boutiquelapsednewsubscribers onlineclients-eyeecomm boutiqueprospects-btqpros onlineprospects-newprospects onlineprospects-prospects boutiqueclients-elite-1 boutiqueclients-elite-2 boutiqueclients-elite-3 boutiqueclients-elite-4 boutiqueclients-hc-1 boutiqueclients-hc-2 boutiqueclients-hc-3 boutiqueclients-hc-4 boutiqueclients-ro-1 boutiqueclients-ro-2 boutiqueclients-ro-3 boutiqueclients-ro-4 boutiqueclients-ta-1 boutiqueclients-ta-2 boutiqueclients-ta-3 boutiqueclients-ta-4 boutiqueclients-ar-1 boutiqueclients-ar-2 boutiqueclients-ar-3 boutiqueclients-ar-4 boutiqueclients-occ-1 boutiqueclients-occ-2 boutiqueclients-occ-3 boutiqueclients-occ-4 boutiqueclients-ha-1 boutiqueclients-ha-2 boutiqueclients-ha-3 boutiqueclients-ha-4 boutiqueclients-lp-1 boutiqueclients-lp-2 boutiqueclients-lp-3 boutiqueclients-lp-4 boutiqueclients-rtw-1 boutiqueclients-rtw-2 boutiqueclients-rtw-3 boutiqueclients-rtw-4 boutiqueclients-rtl-1 boutiqueclients-rtl-2 boutiqueclients-rtl-3 boutiqueclients-rtl-4 boutiqueclients-acc-1 boutiqueclients-acc-2 boutiqueclients-acc-3 boutiqueclients-acc-4 boutiqueclients-acl-1 boutiqueclients-acl-2 boutiqueclients-acl-3 boutiqueclients-acl-4 boutiqueclients-wfj-1 boutiqueclients-wfj-2 boutiqueclients-wfj-3 boutiqueclients-wfj-4 boutiqueclients-fbbtq-1 boutiqueclients-fbbtq-2 boutiqueclients-fbbtq-3 boutiqueclients-fbbtq-4 onlineclients-eyecomm boutiqueclients-btqnews onlineprospects-newpros onlineprospects-pros boutiqueclients-nosegment boutiqueclients-newnosegment boutiqueclients-watchgold boutiqueclients-jewelrygold boutiqueclients-goldfashion boutiqueclients-risinggems boutiqueclients-regulargems boutiqueclients-loyalgems boutiqueclients-ultimate retailprospects onlineprospects-full onlineprospects-light boutiqueclients-newclientswoseg boutiqueclients-others SAB_602 SAB_604 SAB_605 SAB_606 SAB_607 SAB_608 SAB_609 SAB_610 SAB_611 SAB_612 SAB_613 SAB_614 SAB_615 SAB_616 SAB_617 SAB_618 SAB_621 boutiqueclients-highend boutiqueprospects boutiqueclients-btqnews boutiqueclients-sab onlineclients-fbcomm".split(" "),i=
    0;i<list.length;){if(list[i]==google_tag_manager["GTM-KNZ4RBR"].macro(156))var test="True";i++}
    if(!(0<=document.cookie.indexOf("segmentsEDM")&&"True"==test&&google_tag_manager["GTM-KNZ4RBR"].macro(157)==cookieVal)&&"True"==test){var cookieName="segmentsEDM",cookieValue=google_tag_manager["GTM-KNZ4RBR"].macro(158),expirationTime=31556952;expirationTime*=1E3;var date=new Date,dateTimeNow=date.getTime();date.setTime(dateTimeNow+expirationTime);expirationTime=date.toUTCString();document.cookie=cookieName+"\x3d"+cookieValue+"; expires\x3d"+expirationTime+"; path\x3d/; \t\t\tdomain\x3d."+location.hostname.replace(/^www\./i,"")+";SameSite\x3dNone; Secure"};</script>
    <script type="text/javascript" id="">function getCookie(c){c+="\x3d";var b=decodeURIComponent(document.cookie);b=b.split(";");for(var d=0;d<b.length;d++){for(var a=b[d];" "==a.charAt(0);)a=a.substring(1);if(0==a.indexOf(c))return a.substring(c.length,a.length)}return""}for(var cookieVal=getCookie("segmentsOwnedCommerce"),list=["paidsocial-paidsocial_dotcom_2020"],i=0;i<list.length;){if(list[i]==google_tag_manager["GTM-KNZ4RBR"].macro(159))var test="True";i++}
    if(!(0<=document.cookie.indexOf("segmentsOwnedCommerce")&&"True"==test&&google_tag_manager["GTM-KNZ4RBR"].macro(160)==cookieVal)&&"True"==test){var cookieName="segmentsOwnedCommerce",cookieValue=google_tag_manager["GTM-KNZ4RBR"].macro(161),expirationTime=31556952;expirationTime*=1E3;var date=new Date,dateTimeNow=date.getTime();date.setTime(dateTimeNow+expirationTime);expirationTime=date.toUTCString();document.cookie=cookieName+"\x3d"+cookieValue+"; expires\x3d"+expirationTime+"; path\x3d/;             domain\x3d."+location.hostname.replace(/^www\./i,
    "")+";SameSite\x3dNone; Secure"};</script><script type="text/javascript" id="">var url_analytics=document.location.pathname,re_7_fix=RegExp("/l/1x1x9x3/"),re_8_fix=RegExp("/c/1x3x3x1/"),re_9_fix=RegExp("/c/1x3x14x1/"),re_10_fix=RegExp("/c/1x3x15x1/"),re_11_fix=RegExp("/c/1x3x18x2/"),re_12_fix=RegExp("/c/1x3x5x1/"),re_14_fix=RegExp("/c/1x1x3/f/1x2x40/"),re_19_fix=RegExp("/c/1x1x1/f/1x2x40/"),re_42_fix=RegExp("/c/1x3x12x4/"),re_43_fix=RegExp("/c/1x3x21x1/");
    re_7_fix.test(url_analytics)&&-1===url_analytics.indexOf("/f/")?dataLayer.push({category:"fashion",content_type:"products",division:"fsh",divisionFlag:"fsh",sub_category_level1:"products",sub_category_level2:"plp",sub_category_level3:"rtw",sub_category_level4:"jackets",collection:"",page_type:"plp acc - rtw - jackets"}):re_8_fix.test(url_analytics)&&-1===url_analytics.indexOf("/f/")?dataLayer.push({category:"fashion",content_type:"products",division:"fsh",divisionFlag:"fsh",sub_category_level1:"products",
    sub_category_level2:"plp",sub_category_level3:"hdb",sub_category_level4:"boy chanel",collection:"",page_type:"plp acc - hdb - boy chanel"}):re_9_fix.test(url_analytics)&&-1===url_analytics.indexOf("/f/")?dataLayer.push({category:"fashion",content_type:"products",division:"fsh",divisionFlag:"fsh",sub_category_level1:"products",sub_category_level2:"plp",sub_category_level3:"hdb",sub_category_level4:"classic",collection:"",page_type:"plp acc - hdb - classic"}):re_10_fix.test(url_analytics)&&-1===url_analytics.indexOf("/f/")?
    dataLayer.push({category:"fashion",content_type:"products",division:"fsh",divisionFlag:"fsh",sub_category_level1:"products",sub_category_level2:"plp",sub_category_level3:"hdb",sub_category_level4:"2.55",collection:"",page_type:"plp acc - hdb - 2.55"}):re_11_fix.test(url_analytics)&&-1===url_analytics.indexOf("/f/")?dataLayer.push({category:"fashion",content_type:"products",division:"fsh",divisionFlag:"fsh",sub_category_level1:"products",sub_category_level2:"plp",sub_category_level3:"hdb",sub_category_level4:"chanel 19",
    collection:"",page_type:"plp acc - hdb - chanel 19"}):re_12_fix.test(url_analytics)&&-1===url_analytics.indexOf("/f/")?dataLayer.push({category:"fashion",content_type:"products",division:"fsh",divisionFlag:"fsh",sub_category_level1:"products",sub_category_level2:"plp",sub_category_level3:"hdb",sub_category_level4:"chanel's gabrielle",collection:"",page_type:"plp acc - hdb - chanel's gabrielle"}):re_14_fix.test(url_analytics)?dataLayer.push({category:"fashion",content_type:"products",division:"fsh",
    divisionFlag:"fsh",sub_category_level1:"products",sub_category_level2:"plp",sub_category_level3:"",sub_category_level4:"cjy",collection:"21p",page_type:"plp acc - cjy"}):re_19_fix.test(url_analytics)?dataLayer.push({category:"fashion",content_type:"products",division:"fsh",divisionFlag:"fsh",sub_category_level1:"products",sub_category_level2:"plp",sub_category_level3:"hdb",sub_category_level4:"all handbags",collection:"21p",page_type:"plp acc - hdb"}):re_42_fix.test(url_analytics)&&-1===url_analytics.indexOf("/f/")?
    dataLayer.push({category:"fashion",content_type:"products",division:"fsh",divisionFlag:"fsh",sub_category_level1:"products",sub_category_level2:"product homepage",sub_category_level3:"hdb",sub_category_level4:"new this season",collection:"",page_type:"product homepage - hdb - new this season"}):"plp acc - hdb - classic"==google_tag_manager["GTM-KNZ4RBR"].macro(162)&&"plp"==google_tag_manager["GTM-KNZ4RBR"].macro(163)&&"hdb"==google_tag_manager["GTM-KNZ4RBR"].macro(164)?dataLayer.push({category:"fashion",content_type:"products",division:"fsh",divisionFlag:"fsh",sub_category_level1:"products",
    sub_category_level2:"product homepage",sub_category_level3:"hdb",sub_category_level4:"classic",collection:"",page_type:"product homepage - hdb - classic"}):"plp acc - hdb - 2.55"==google_tag_manager["GTM-KNZ4RBR"].macro(165)&&"plp"==google_tag_manager["GTM-KNZ4RBR"].macro(166)&&"hdb"==google_tag_manager["GTM-KNZ4RBR"].macro(167)?dataLayer.push({category:"fashion",content_type:"products",division:"fsh",divisionFlag:"fsh",sub_category_level1:"products",sub_category_level2:"product homepage",sub_category_level3:"hdb",sub_category_level4:"2.55",collection:"",page_type:"product homepage - hdb - 2.55"}):
    "plp acc - hdb - chanel 19"==google_tag_manager["GTM-KNZ4RBR"].macro(168)&&"plp"==google_tag_manager["GTM-KNZ4RBR"].macro(169)&&"hdb"==google_tag_manager["GTM-KNZ4RBR"].macro(170)?dataLayer.push({category:"fashion",content_type:"products",division:"fsh",divisionFlag:"fsh",sub_category_level1:"products",sub_category_level2:"product homepage",sub_category_level3:"hdb",sub_category_level4:"chanel 19",collection:"",page_type:"product homepage - hdb - chanel 19"}):"chanel's gabrielle - handbags | chanel"==google_tag_manager["GTM-KNZ4RBR"].macro(171)?dataLayer.push({category:"fashion",content_type:"products",
    division:"fsh",divisionFlag:"fsh",sub_category_level1:"products",sub_category_level2:"product homepage",sub_category_level3:"hdb",sub_category_level4:"chanel's gabrielle",collection:"",page_type:"product homepage - hdb - chanel's gabrielle"}):"plp acc - hdb - boy chanel"==google_tag_manager["GTM-KNZ4RBR"].macro(172)&&"plp"==google_tag_manager["GTM-KNZ4RBR"].macro(173)&&"hdb"==google_tag_manager["GTM-KNZ4RBR"].macro(174)?dataLayer.push({category:"fashion",content_type:"products",division:"fsh",divisionFlag:"fsh",sub_category_level1:"products",sub_category_level2:"product homepage",
    sub_category_level3:"hdb",sub_category_level4:"boy chanel",collection:"",page_type:"product homepage - hdb - boy chanel"}):re_43_fix.test(url_analytics)&&dataLayer.push({category:"fashion",content_type:"products",division:"fsh",divisionFlag:"fsh",sub_category_level1:"products",sub_category_level2:"product homepage",sub_category_level3:"hdb",sub_category_level4:"chanel 22",collection:"",page_type:"product homepage - hdb - chanel 22"});</script><script type="text/javascript" id="">window.performance&&window.performance.mark("sec_gtm_loaded");</script>

<script src="front_end_2/otBannerSdk.js" async="" type="text/javascript"></script>
<script charset="utf-8" src="front_end_2/language-navigation-popin.js"></script>


<script type="text/javascript">
    /*<![CDATA[*/
    
    var ACC = { config: {} };
        ACC.config.contextPath = "";
        ACC.config.encodedContextPath = "/fr";
        ACC.config.commonResourcePath = "/_ui/responsive/common";
        ACC.config.themeResourcePath = "/_ui/responsive/theme-onechanel";
        ACC.config.siteResourcePath = "/_ui/responsive/site-chanel_fr";
        ACC.config.rootPath = "/_ui/responsive";	
        ACC.config.CSRFToken = "c5c75b5d-a144-4d13-8ee2-cfc3fed82f41";
        ACC.pwdStrengthVeryWeak = 'Trop faible';
        ACC.pwdStrengthWeak = 'Faible';
        ACC.pwdStrengthMedium = 'Moyenne';
        ACC.pwdStrengthStrong = 'Forte';
        ACC.pwdStrengthVeryStrong = 'Trop forte';
        ACC.pwdStrengthUnsafePwd = 'password.strength.unsafepwd';
        ACC.pwdStrengthTooShortPwd = 'Trop court';
        ACC.pwdStrengthMinCharText = '%d caractères minimum';
        ACC.accessibilityLoading = 'Chargement… Veuillez patienter…';
        ACC.accessibilityStoresLoaded = 'Boutiques chargées';
        ACC.config.googleApiKey="";
        ACC.config.googleApiVersion="3.7";

        ACC.autocompleteUrl = '/fr/search/autocompleteSecure';

        ACC.config.loginUrl = '/fr/login';

        ACC.config.authenticationStatusUrl = '/fr/authentication/status';

    /*]]>*/
</script>
<script type="text/javascript">
/*<![CDATA[*/
ACC.addons = {};	//JS holder for addons properties
        
    ACC.addons.onechanelasmaddon = [];
    
            ACC.addons.onechanelasmaddon['asm.timer.min'] = 'min';
        
    ACC.addons.onechanelchinaaddressaddon = [];
    
    ACC.addons.onechanelbuynowaddon = [];
    
    ACC.addons.onechanelchinesepaymentsaddon = [];
    
    ACC.addons.smarteditaddon = [];
    
    ACC.addons.onlinerepairtrackingaddon = [];
    
/*]]>*/
</script>

<script type="text/javascript">
        window.config = window.config || {};
        window.config.search = {
facet: {
    title: {
        'watches.tridiv_subcollection': 'sous-collection',
        'watches.tridiv_collection': 'Collections',
        'watches.tridiv_line': 'Esthétique',
        'watches.tridiv_subcollection_united_states': 'sous-collection',
        'watches.tridiv_collection_united_states': 'Collections',
        'watches.tridiv_line_united_states': 'Esthétique',
        'watches.wfj_materials': 'Matériaux',
        'watches.wfj_dimension': 'Taille de boîte',
        'watches.wfj_variant_movement': 'Mouvement',
        'watches.wfj_complications': 'Complication',
        'watches.wfj_calibre': 'Calibre CHANEL',
        'watches.tridiv_variant_limitededition': 'Édition limitée',
        'watches.tridiv_variant_new': 'Nouveauté',
        'jewelry.tridiv_collection': 'Collections',
        'jewelry.tridiv_category': 'Catégories',
        'jewelry.tridiv_collection_united_states': 'Collections',
        'jewelry.tridiv_collection_japan': 'Collections',
        'jewelry.tridiv_category_united_states': 'Catégories',
        'jewelry.wfj_materials': 'Matériaux',
        'jewelry.tridiv_variant_new': 'Nouveauté',
        'fragrance.tridiv_collection': 'Franchise',
        'fragrance.tridiv_collection_united_states': 'Franchise',
        'fragrance.tridiv_subcategory': 'Franchise',
        'fragrance.tridiv_subcategory_united_states': 'Franchise',
        'fragrance.fnb_variant_contenance': 'Contenance',
        'fragrance.fnb_variant_concentration': 'Catégories',
        'fragrance.fnb_variant_scentfamily': 'Famille olfactive',
        'fragrance.fnb_variant_pack': 'Format',
        'makeup.fnb_variant_finish': 'Finition',
        'skincare.fnb_variant_apparea': 'Zone d’application',
        'fragrance.tridiv_variant_exclusive': 'Exclusivité',
        'fragrance.tridiv_variant_limitededition': 'Édition limitée',
        'fragrance.tridiv_variant_comingsoon': 'Prochainement',
        'fragrance.tridiv_variant_foreignedition': 'Édition étrangère',
        'fragrance.tridiv_variant_new': 'Nouveauté',
        'makeup.tridiv_collection': 'Collection',
        'makeup.tridiv_collection_united_states': 'Collection',
        'makeup.tridiv_subcategory': 'Catégories',
        'makeup.tridiv_subcategory_united_states': 'Catégories',
        'makeup.fnb_variant_harmony': 'Harmonie',
        'makeup.fnb_variant_texture': 'Textures',
        'makeup.tridiv_variant_exclusive': 'Exclusivité',
        'makeup.tridiv_variant_limitededition': 'Édition limitée',
        'makeup.tridiv_variant_comingsoon': 'Prochainement',
        'makeup.tridiv_variant_foreignedition': 'Édition étrangère',
        'makeup.tridiv_variant_new': 'Nouveauté',
        'makeup.fnb_variant_coverage': 'Couvrance',
        'makeup.fnb_variant_benefits': 'Bénéfices',
        'skincare.tridiv_category': 'Catégories',
        'skincare.tridiv_collection': 'Collection',
        'skincare.tridiv_category_united_states': 'Catégories',
        'skincare.tridiv_collection_united_states': 'Collection',
        'skincare.fnb_benefits': 'Avantages',
        'skincare.fnb_variant_texture': 'Textures',
        'skincare.tridiv_variant_exclusive': 'Exclusivité',
        'skincare.tridiv_variant_limitededition': 'Édition limitée',
        'skincare.tridiv_variant_comingsoon': 'Prochainement',
        'skincare.tridiv_variant_new': 'Nouveauté',
        'skincare.fnb_variant_productcategories': 'besoins',
        'skincare.fnb_variant_benefits': 'Bénéfices',
        'skincare.fnb_variant_subbenefits': 'Bénéfices',
        'fashion.fsh_variant_collection': 'Collection',
        'fashion.tridiv_category': 'Créations',
        'fashion.tridiv_subcategory': 'Catégorie',
        'fashion.tridiv_collection': 'Collection',
        'fashion.tridiv_line': 'Thème',
        'fashion.tridiv_category_united_states': 'Créations',
        'fashion.tridiv_subcategory_united_states': 'Catégorie',
        'fashion.tridiv_collection_united_states': 'Collection',
        'fashion.tridiv_line_united_states': 'Thème',
        'Fashion.tridiv_variant_new': 'Nouveaux produits',
        'fashion.tridiv_variant_exclusive': 'Exclusivité',
        'fashion.tridiv_variant_limitededition': 'Édition limitée',
        'fashion.tridiv_variant_comingsoon': 'Prochainement',
        'fashion.fsh_variant_intheshow': 'Défilé',
        'fashion.fsh_fabricfacet': 'Matière',
        'fashion.fsh_dimension': 'Dimension',
        'fashion.fsh_variant_specialfinishfacet': 'Hauteur du talon',
        'fashion.fsh_variant_specialfinishfacet_mm': 'mm - afficher la hauteur du talon en millimètres',
        'fashion.fsh_variant_specialfinishfacet_in': 'in - afficher la hauteur du talon en pouces (in)',
        'fashion.fsh_variant_colorfacet': 'Couleur',
        'fashion.fsh_variant_hardware': 'Finition',
        'eyewear.fsh_variant_collection': 'Collection',
        'eyewear.tridiv_category': 'Catégorie',
        'eyewear.tridiv_subcategory': 'Forme',
        'eyewear.tridiv_category_united_states': 'Catégorie',
        'eyewear.tridiv_subcategory_united_states': 'Forme',
        'eyewear.tridiv_collection': 'Collection',
        'eyewear.tridiv_line': 'Catégorie',
        'eyewear.tridiv_collection_united_states': 'Collection',
        'eyewear.tridiv_line_united_states': 'Catégorie',
        'eyewear.tridiv_subline': 'Thème',
        'eyewear.tridiv_subline_united_states': 'Thème',
        'eyewear.fsh_variant_colorgroup': 'Couleur',
        'eyewear.fsh_variant_colorfacet': 'Couleur',
        'eyewear.fsh_treatment': 'Verres',
        'eyewear.fsh_variant_prescriptionfriendly': 'Compatible avec des verres prescription',
        'eyewear.tridiv_variant_new': 'Nouveaux produits',
        'eyewear.tridiv_variant_exclusive': 'Exclusivité',
        'eyewear.tridiv_variant_limitededition': 'Édition limitée',
        'eyewear.tridiv_variant_comingsoon': 'Prochainement',
        'eyewear.fsh_variant_treatment': 'Verres',
        'eyewear.fsh_variant_specialfinishfacet': 'Largeur des verres',
        'eyewear.fsh_variant_progressivefriendly': 'Compatible avec des verres progressifs',
        'watches.wfj_functions': 'fonction'   
    },
    value: {
        'other.colors': 'Autres couleurs',
        'other.handbags': 'Autres sacs',
        'other.categories': 'Autres catégories',
        'other.dimensions': 'Autres dimensions',
        'other.colors': 'Autres couleurs',
        'fabrics.tweedsfabrics': 'Tweeds et tissus',
        'other.costumejewelry': 'Autres bijoux fantaisie',
        'other.fabrics': 'Autres tissus',
        'other.materials': 'Autres matières',
        'other.smallleathergoods': 'Autre petite maroquinerie',
        'shape.butterfly': 'Papillon',
        'shape.cateye': 'Œil de chat',
        'shape.clipon': 'Clip',
        'shape.oval': 'Ovale',
        'shape.pantos': 'Pantos',
        'shape.pilot': 'Pilote',
        'shape.pouchescases': 'Pochettes & trousses',
        'shape.rectangle': 'Rectangle',
        'shape.round': 'Rond',
        'shape.shield': 'Masque',
        'shape.square': 'Carré',
        'shape.visor': 'Visière',
        'theme.newthisseason': 'Nouveautés',
        'theme.timeless': 'Essentiels',
        'theme.exclusive': 'Exclusivités',
        'theme.classics': 'Sac à main classique',
        'theme.2.55': 'Sac à main 2.55',
        'height.high': 'Talon haut',
        'height.mid': 'Talon mi-haut',
        'height.low': 'Talon bas',
        'gradient': 'Dégradé',
        'glitter': 'Scintillant',
        'mirror': 'Miroir',
        'polarized': 'Polarisés',
        'scintillant': 'Scintillant',
        'category.runway': 'Défilé',
        'category.timeless': 'Essentiels',
        'materials.beigegold': 'OR BEIGE',
        'materials.satinstrap': 'Bracelet en satin',
        'materials.rubberstrap': 'Bracelet en caoutchouc',
        'materials.alligatorstrap': 'Bracelet en alligator',
        'materials.leatherstrap': 'Bracelet en cuir',
        'dimensions.small': 'Petite',
        'dimensions.medium': 'Moyenne',
        'dimensions.large': 'Grande',
        'movement.mechanicalselfwinding': 'Mécanique à remontage automatique',
        'movement.mechanicalmanualwinding': 'Mécanique à remontage manuel',
        'movement.highprecisionquartz': 'Quartz haute précision',
        'concentration.bathandbody': 'Bain et corps',
        'concentration.parfum': 'Parfum',
        'subcategory.giftsets': 'Coffrets cadeau',
        'harmony.red': 'Rouge',
        'harmony.pink': 'Rose',
        'harmony.neutral': 'Neutre',
        'harmony.other': 'Autre',
        'category.cleansersandtoners': 'Démaquillants et lotions',
        'category.eyelipcare': 'Soin des yeux et des lèvres',
        'category.masks': 'Masques et gommages',
        'category.moisturizers': 'Soins hydratants',
        'category.serums': 'Sérums',
        'category.sunprotection': 'Protection solaire',
        'category.bodycare': 'Soin du corps',
        'category.others': 'Autres',
        'collection.lasolution10': 'La Solution 10 de Chanel',
        'collection.resynchronizing': 'Soins Resynchronisation',
        'benefits.ageprevention': 'Premiers signes de l’âge',
        'benefits.sublimage': 'Régénération & Éclat',
        'benefits.collectionlumiere': 'Régénération & Uniformité',
        'benefits.extraits': 'Régénération & Réparation',
        'benefits.allsublimage': 'Éclat & Perfection',
        'benefits.antiwrinkle': 'Anti-âge et lifting',
        'benefits.cleansing': 'Démaquillants et lotions',
        'benefits.antiaging': 'Anti-âge global',
        'benefits.hydration': 'Hydratation',
        'benefits.soothing': 'Apaisement et équilibre',
        'benefits.brightening': 'Illumination',
        'benefits.sunprotection': 'Protection solaire',
        'usage.fragrance': 'Parfums',
        'usage.bathbody': 'Bain et corps',
        'format.others': 'Autres',
        'finish.multiple': 'Multiple',
        'texture.others': 'Autres',
        'apparea.handsnails' : 'Ongles et mains',
        'usage.grooming': 'Rasage',
        'transparent': 'Transparent',
        'harmony.beige': 'Beige',
        'harmony.rosebeige': 'Beige rosé',
        'harmony.goldenbeige': 'Beige doré',
        'harmony.yellowbeige': 'Beige jaune',
        'harmony.coral': 'Corail',
        'harmony.apricot': 'Abricot',
        'harmony.intensebeige': 'Beige intense',
        'harmony.green': 'Vert',
        'texture.fluid': 'Fluide',
        'texture.cream': 'Crème',
        'texture.compactpowder': 'Poudre compacte',
        'bluelight': 'Filtre anti-lumière bleue',
        'leseaux': 'Les Eaux de CHANEL',
        'lens.small': 'Petite (46\/48 mm)',
        'lens.medium': 'Moyenne (49\/52 mm)',
        'lens.large': 'Large (53\/56 mm)',
        'lesexclusifs': 'Les Exclusifs de CHANEL',
        'boycategories.foundation': 'Fond de Teint',
        'boycategories.concealer': 'Correcteur',
        'boycategories.eyepencil': 'Stylo Yeux',
        'boycategories.eyebrow': 'Le Stylo Sourcils',
        'boycategories.lipbalm': 'Le Baume à Lèvres',
        'categories.nailcolour': 'Vernis à ongles',
        'texture.balm': 'Baume',
        'watches.finewatchmaking': 'Haute Horlogerie',
        'category.boydechanel': 'BOY DE CHANEL',
        'watches.wfj_variant_haute_horlogerie': 'Haute Horlogerie'
    },
},
noSearchExeptionUrl: '/fr/search?text={0}&error=true',
availableShadesText:'Coloris disponibles',
totalShadesTextSingular:'{0} coloris disponible',
totalShadesTextPlural:'{0} coloris disponibles',
plusText:'plus',
acc:'Accessoires',
rtw:'Prêt-à-porter',
noResultFoundLabel: 'Aucun résultat trouvé, les suggestions de recherche sont affichées ci-dessous',
labelOneSuggestion: 'Un lien suggéré',
labelManySuggestions: '{0} liens suggérés',
inLabel: 'in',
labelClose: 'Annuler',
searchHeading: 'Rechercher',
labelResultsIn: '{0} résultats en {1}',
searchResults: 'Résultats de la recherche',
labelOneResultIn: '{0} résultat en {1}',
searchInputAriaHidden: 'Les liens suggérés s’affichent en fonction de votre recherche',
searchInputLabel: 'rechercher',
searchClear: 'Effacer',
searchSubmit: 'Valider votre recherche',
suggestionsType: 'Produits',
recentSearchClear: 'Supprimer l’historique',
recentSearchTitle: 'Recherche récente',
seeMoreFilters: 'Voir plus',
filters: 'Filtres',
filtersClear: 'Effacer',
filtersClearLabel: 'Effacer les filtres',
filtersApply: 'Appliquer les filtres',
priceFrom: 'De',
priceFromTitle: 'De prix minimum - les résultats seront mis à jour automatiquement',
priceTo: 'À',
priceToTitle: 'À prix maximum - les résultats seront mis à jour automatiquement',
help:'Aide',
stories:'Histoires',
moreStories: 'Voir plus d’histoires',
moreHelp: 'Voir plus d’aide',
moreProduct: 'Voir plus de produits',
quickLinks: 'Suggestions',
externalLink: 'search.external.link',
videoSlideShow: 'content.story.videoslideshow',
video: 'content.story.video',
music: 'content.story.music',
podcast: 'content.story.podcast',
slideShow: 'content.story.slideshow',
helpView: 'Voir',
closeCta: 'Fermer',
filtersSpecialText: 'Filtres spéciaux',
nofilterResult: 'Résultats',
emptySearchText: 'Aucun résultat trouvé pour “{0}”',
NeedHelpSeparator: 'ou',
emptySearchTryNewSearch: 'Veuillez essayer une nouvelle recherche ou parcourez les catégories CHANEL pour trouver ce que vous recherchez.',
filterResult: 'Résultats ({0})',
filterResults: 'Résultats ({0})',
filterClearAll: 'Tout supprimer',
filtersClearAllLabel: 'Effacer tous les filtres',
addToWishlist : 'Ajouter à la liste de souhaits',
removeFromWishlist : 'Supprimer de la liste de souhaits',
productColor : 'Coloris',
addToBag: 'AJOUTER AU PANIER',
tryOnButton: 'Essayer et comparer',
inChanelCustomer: 'Dans le cadre de l’expérience InCHANEL, vous avez accès à un catalogue de produits étendu.',
discoverBoutiqueNot: {
    showNotText: '',
    closeCta: '',
    minimizeText: '',
    maximizeText: ''
},
product: {
    content: 'Produits',
    result: '{0} résultat',
    results: '{0} résultats'
},
maxLinks: '3',
addresses: false ? '/fr/yapi/suggest?search={0}' : '/api/search/suggest?search={0}&scope=//catalog01/fr_FR/tridiv_variant_market<{france}',
baseUrl: '/fr', // remove the last slash in the base url
titleResultsIn: '{0} résultats pour {1} dans {2}',
titleOneResultIn: '{0} résultat pour {1} dans {2}',
searchUrl: '/fr/search/',
noSearchUrl: '/fr/search?text={0}&noResults=true',
cookieMaxDays: '14',
fhLocal: 'fr_FR-france',
filtersCloseLabel: 'Fermer les filtres et accéder aux résultats',
filtersTrayCloseLabel: 'Fermer les filtres',
retailSuggestedPrice: {
    text: '',
    text1: '* Prix de vente suggéré.',
    title: 'En savoir plus sur le prix de vente suggéré',
    text2: 'En savoir plus'
},
priceMoreInformation: {
    text1: 'Pour les prix à Hawaï/Guam,',
    text2: 'nous contacter'
},
priceMention: {
    text: ''
},
priceIncluding: {
    text: ''
},

disclaimerFirstUrl: 'https://services.chanel.com/fr_FR/policies/legal',
disclaimerSecondUrl: 'https://services.chanel.com/en_US/contact',

pricemoreinformation: '',
variantPriceTitle: 'Prix',
searchProductDisclaimerPrice : 'informations sur le prix'
};
    </script>
 <script type="text/javascript" id="jsConfig">
window.config = {
    ...window.config,
    axisType: '',
    gigyaSSOBlock: {
        ssoBlockUserEnabled: 'true',
        ssoBlockError: 'Il existe déjà un compte CHANEL associé à cette adresse e-mail pour un autre lieu. Veuillez modifier votre emplacement pour vous connecter avec cette adresse e-mail ou en utiliser une autre pour créer un nouveau compte.'
    },
    isLogged: false,
    oabGuestMode: ``,
    rightToLeftLanguage: false,
    pageTitle: `CHANEL Site Officiel : Mode, Parfum, Beauté, Horlogerie, Joaillerie | CHANEL`,
    targetVersion: `?v=3.35.5`,
    isEGiftCardPresent: ``,
    isStandardProductPresent: ``,
    isOABServiceProductPresent: ``,
    enableTouchPoints : ``,
    conciergeDelivery: {
        seeMoreBtn: 'Voir plus',
        seeLessBtn: ''
    },
    efo: {
        ftraConfigUrl: '//conf.f-tra.com/ffconf/ffconf_0786_0004_0007.js',
        ftraAssetUrl: '//asset.f-tra.com/track/efo2.js',
        ftraSidepanelConfigUrl: '//conf.f-tra.com/ffconf/ffconf_0786_0004_0013.js'
    },
    chinaCaptcha: {
        configUrl: 'https://cstaticdun.126.net/load.min.js',
        configToken: '2b59b679283e4bbd94e7c20e6b293b4f'
    },
    popinCookie: {
        popinDisplay : false,
        popinMessage : 'I choose and accept to navigate on the CHANEL website with an international language',
        languageDescriptor : '/fr',
        popinBtnText : 'ACCEPT',
        popinExportLabel : 'text.export.label'
    },
    popinCompatibility: {
        popinTitle: 'Votre navigateur Web \u003Cbr\u003Ene semble pas être à jour',
        popinMessage: 'Pour visualiser ce contenu, nous vous recommandons d\'utiliser la dernière version de Safari, Firefox ou Chrome. Ou \u003Cbutton type=\"button\" class=\"link is-underline browser-comp-link\"\u003E\u003Cspan class = \"is-sr-only\"\u003E\u003C\/span\u003E\u003Cspan class=\"button__wrapper\"\u003Ecliquez ici\u003C\/span\u003E\u003C\/button\u003E pour continuer à parcourir le site de CHANEL.com',
        popinLabel : 'text.browser.compatibility.label',
        popinCloseLabel: 'text.browser.compatibility.closeButtonlabel'
    },
    notifierNotify: {
        notifierTitle: '',
        notifierDesc: '',
        close: ''
    },
    popinNotifyMe: {
        popinTitle: 'M’avertir',
        popinSubmitLabel: 'Valider',
        popinLabel: 'L\'adresse e-mail',
        popinDescription: 'Indiquez votre adresse e-mail afin de recevoir une notification dès que cet article sera disponible.',
        popinCloseLabel: 'Fermer la fenêtre M’avertir',
        popinEmailLabel: 'Adresse e-mail',
        popinCountryCodeLabel: 'Indicatif pays',
        popinPhoneNumberLabel: 'Téléphone',
        popinTermsAndConditions: '',
        popinTermsAndConditionsCN: '',
        popinAgreeConditionCheck: '',
        popinAgreeCondition: '',
        popinDiscalimer: '',
        popinIsoCode: 'country.isocode.value',
        popinError: '',
        privacyandtermsError: '',
        emailTitle: 'e-mail - par ex. : nom@mail.com',
        popinNotifyAvailableText: 'M’avertir de sa disponibilité',
        popinNotice:'',
        popinTermsAndConditionsRU: ''
    },
    popinThankyou: {
        popinTitle: 'Merci',
        popinMessage: 'Vous serez informé(e) de la disponibilité de cet article à l’adresse {emailaddress}.',
        continueShoppingBtnText: 'POURSUIVRE MES ACHATS',
        popinMsg: 'Vous serez informé(e) de la disponibilité de cet article à l’adresse {emailaddress}.',
        popinCloseHiddenText: 'Fermer la fenêtre Merci'
    },
    popinCallback: {
        callbackDate: '',
        callbackTime: '',
        callbackReason: '',
        callbackInterest: '',
        contactName: '',
        contactNameLocal: '',
        emailLabel: 'E-mail',
        emailTitle: 'e-mail - par ex. : nom@mail.com',
        phoneLabel: 'Numéro de téléphone',
        countryCodeLabel: 'Indicatif pays',
        fieldsMandatory: 'Tous les champs sont obligatoires.',
        popinTitle: '',
        popinClose: '',
        popinConfirmationTitle: '',
        popinConfirmationClose: '',
        popinConfirmationMessage: '',
        advisorClose: '',
        advisorMessage: '',
        call: 'Téléphone',
        liveChat: 'Discussion en direct',
        callbackYapi: '/fr/yapi/webcallback/',
        callbackSubmitYapi: '/fr/yapi/webcallback/submit',
        callTitle: '',
        callMessage: '',
        callbackTitle: '',
        callbackMessage: '',
        submitButton: '',
        closeButton: '',
        closeButtonInnerText: '',
        chanelLiveConnect: ''
    },
    popinLookPDP: {
        closeLabel: 'Fermer l’aperçu {0}',
        modalLabel: 'Look {0}',
        lookDataUrl: '/fr/yapi/product/lookData/{0}',
        lookSwipeData: '/fr/yapi/product/lookSwipeD/{0}',
        viewDetailLabel: 'voir tous les détails - {0}',
        viewProductDetailsCta: 'Voir les détails',
        lookCategory : 'Vidéo en pause {0} - Look {1}',
        videoAriaLabel : 'Vidéo {0} - Look {1}',
        videoAccountId : 6057940567001,
        disclaimerText1: '* Prix de vente suggéré.',
        disclaimerText2: 'En savoir plus',
        disclaimerTitle: 'En savoir plus sur le prix de vente suggéré',
        policyURL: 'https://services.chanel.com/fr_FR/policies/legal',
        disclaimerAlly: 'Retour au contenu',
        priceInfoAriaLabel : 'informations prix',
        lookCardNumber : 'Look {0}',
        lookImageAltText : 'Image {0} - Look {1}',
        dialogBtnLabel: 'zoom - Look {0}',
        lookZoomImageAlt : 'zoom - {0}',
        priceOnRequest : 'Prix sur demande'
    },
    popin3DS2: {
        authLabelTitle: 'Authentifier le paiement'
    },
    popinLocationConsent: {
        label: '',
        heading: '',
        description: '',
        acceptBtn: '',
        declineBtn: ''
    },
    currentLocale: `/fr/`,
    oab : {
        title: 'Prendre rendez-vous',
        backButton: 'Retour',
        dateSelection: {
            errors: {
                invalidDate: 'Le format de date utilisé n’est pas valide. Veuillez indiquer la date de votre rendez-vous au format suivant : 31\/12\/2019',
                unavailableDate: 'Malheureusement, aucun rendez-vous n’est disponible à cette date. Veuillez choisir un autre jour.',
                unavailableServiceDate: 'Malheureusement, ce service est indisponible. Veuillez prendre rendez-vous dans une autre boutique.'
            },
            title: 'Date',
            cta: 'Confirmez votre sélection',
            okCta: 'Ok',
            editCta: 'Modifier',
            timeSlotFromText: 'De',
            timeSlotToText: 'à'
        },
        axisType: {
            skincare: 'Soin',
            eyewear: 'Lunettes',
            watches: 'Horlogerie Joaillerie',
           'watches-jewellery': 'Horlogerie Joaillerie',
            makeup: 'PARFUMS ET BEAUTÉ',
            jewelry: 'Joaillerie',
            fragrance: 'Parfums',
            fashion: 'Mode'
        },
        boutiqueSelection: {
            title: 'SÉLECTION DE LA BOUTIQUE',
            backToActiveTabText: 'RETOUR AU MODE DE VUE',
            listTab: 'LISTE DES BOUTIQUES',
            mapTab: 'VOIR SUR LA CARTE',
            boutiqueInfoBox: 'BOUTIQUE SELECTIONNEE'
        },
        description: {
            serviceSelectionCta : 'Choisir ce service'
        },
        phoneNumber: {
            title: 'Confirmez votre rendez-vous',
            reviewPlaceHolder: '(Occasion particulière, préférences concernant les produits, demande spéciale, langue préférée …)',
            guestModeConfirmationCta: 'Confirmer le rendez-vous',
            confirmationCta: 'CONFIRMEZ'
        },
        redirectAccount: {
            title: 'FINALISEZ VOTRE RENDEZ-VOUS'
        },
        thanksMessage: {
            title: 'Merci'
        },
        servcieSelection: {
            bookCtaText: 'PRENDRE RENDEZ-VOUS'
        },
        oabDurationUnit:'MIN',
        imageAltTexts: {
            AfterSalesServices : 'Services après-vente',
            SeeCollection : 'Voir la collection',
            VirtualAppointment : 'Rendez-vous virtuel',
            DiscoverCollection: 'Découvrez la collection',
            CareMaintenance : 'Conseils et services',
            SpecialSomeone : 'Pour un être cher',
            Bridal : 'Mariage',
            IconicFifteenMinutes : 'Quinze minutes iconiques',
            AlchemicalFifteenMinutes : 'Quinze minutes d’alchimie',
            TopicFifteenMinutes : 'Quinze minutes toniques',
            PersonalSkincareCoach : 'Mon coach personnel de soins',
            PersonalMakeupCoach : 'Mon coach personnel de maquillage',
            ChanelSignatureLook: 'Le look signature de Chanel',
            TwistLine : 'Jouez avec les associations',
            WokeUpLikeThis : 'Je me suis réveillée comme ça',
            BeautyConsult : 'Conseil beauté',
            PersonalSkincareCoachVirtual : 'Mon coach personnel de soins - Service virtuel',
            PersonalMakeupCoachVirtual: 'Mon coach personnel de maquillage - Service virtuel',
            PersonalFragranceCoachVirtual : 'Mon coach personnel de parfums - Service virtuel',
            ChanelMakeupLesson : 'Le cours de maquillage Chanel',
            ChanelMakeupLessonVirtual : 'Le cours de maquillage Chanel - Service virtuel',
            ChanelFragranceSignature : 'Les parfums Chanel signature',
            ChanelFragranceSignatureVirtual : 'Les parfums Chanel signature - Service virtuel',
            ChanelSkincareEssential : 'Les soins essentiels Chanel',
            ChanelSkincareEssentialVirtual : 'Les soins essentiels Chanel - Service virtuel',
            DiscoverLatestCreations : 'Découvrez les nouvelles créations',
            MakeupVideoChat : 'Chat vidéo de maquillage',
            SkincareVideoChat : 'Chat vidéo de soins',
            FragranceVideoChat : 'Chat vidéo de parfums',

            EyeCare : 'Soins des yeux',
            TheBasic : 'Les basiques',
            WeddingDay : 'Jour du mariage',
            CatwalkLook : 'Look de défilé',
            MyParty : 'C’est ma fête',
            ExpressStyle : 'Exprimez votre style',
            LegendaryFragrance : 'Parfums légendaires',
            ChanelExclusive : 'Exclusivités Chanel',
            ChanelSkincareEssential : 'Les soins essentiels Chanel',
            ArtPerfuming : 'L’Art du Parfum',
            Handcare : 'Soins des mains',
            SkincareFreshness : 'La fraîcheur des soins',
            ChanelAllure : 'Allure Chanel',
            CreateLook : 'Créez votre look',
            EssentialRitual : 'Le rituel essentiel',
            IdealRitual : 'Le rituel idéal',
            BodyCare : 'Les soins du corps',
            SeasonalCare : 'Les soins de saison',
            IlluminatingCare : 'Les soins enlumineurs',
            FirmingCare : 'Les soins raffermissants',
            RevitalizingCare : 'Les soins revitalisants',
            SublimeCare : 'Les soins sublimes',
            HolidayChanel : 'Vacances Chanel',
            PearlBrightness : 'L’éclat des perles',
            ChanelMoment : 'L’instant Chanel',
            Mat : 'Le mat',
            Principal : 'Le principal',
            MakeupRetouch : 'Retouches de maquillage'
        },
        oabSpaceLeft: {
        timeSlotMoreText : 'Plus de 5 places restantes',
        timeSlotPlacesText : 'places restantes',
        timeSlotPlaceText : 'place restante'
    }
    },
    reviewsSelectOptions: {
        dateCreated_desc: 'Les plus récents',
        rating_desc: 'Notes les plus élevées',
        rating_asc: 'Notes les plus basses',
        upVotes_desc: 'Les plus utiles'
    },
    storeCarousel: {
        storeTitle: 'Trouver une boutique',
        storeCarouselOverlayCloseTest: 'Fermer l’outil Trouver une boutique'
    },
    ratingsAndReviews: {
        baseUrl: '/fr',
        ratingMaxStars: 5,
        a11yCloseModal: 'Fermer',
        confirmationMessage: {
            header: 'Merci de votre commentaire.',
            body: 'Votre avis a bien été envoyé. Il devrait apparaître en ligne sous 48 heures.',
            a11y: 'Merci'
        },
        unsubscribeMessage: {
            header: 'Votre désabonnement a bien été pris en compte',
            body: 'Votre désabonnement a bien été pris en compte.\u003Cbr\u003EVous ne recevrez plus de messages concernant les articles que vous avez achetés sur CHANEL.com',
            a11y: 'Merci'
        },
        secondReviewMessage: {
            header: 'Merci de votre avis',
            body: 'Nous avons déjà reçu votre avis sur ce produit.',
            a11y: 'Merci'
        },
        notPurchaserMessage: {
            header: 'Nous sommes désolés.',
            body: 'Pour soumettre un avis, vous devez avoir acheté ce produit sur chanel.com et vous ne pouvez soumettre qu\'un avis par produit.',
            a11y: 'Fermer la fenêtre Nous sommes désolés'
        },moderationRules: {
            header: 'Charte de modération',
            body: 'Chaque avis est modéré manuellement par notre Service Client avant sa publication afin de vérifier sa conformité avec nos critères de publication consultables dans les {0}. Les avis seront publiés indépendamment de leur note à partir du moment où ils respectent les critères de publication. Pour pouvoir rédiger un avis sur l’un de nos produits, le consommateur doit avoir préalablement acheté le produit sur {1} au cours de la dernière année. Les avis sont affichés sur notre site par ordre chronologique.',
            bodyLegalMentions: 'mentions légales',
            bodyChanelDotCom: 'CHANEL.com',
            url: 'https://services.chanel.com/{0}/policies/legal'
        },
        purchaseDate: {
            label: 'Date d’achat'
        },
        reviewCta: {
            label: 'Achat vérifié'
        },
        incentivizedReview: ''
    },
    giftcardBalancePopin: {
        closeBtn: 'giftcard.balance.popin.close.cta',
        title: 'Solde carte cadeau',
        description: 'Vérifier le solde de votre carte cadeau',
        formCardNumberLabel: 'Numéro de carte',
        formCardPinLabel: 'Code Pin',
        formNumbersHelp: 'Où trouver ces informations ?',
        formInformations: 'Le solde et la date de validité de la carte cadeau sont consultables par téléphone auprès de notre service clients au {1}.',
        formInformationsUk: '',
        formSubmitCta: 'CONSULTER LE SOLDE',
        formSubmitCtaAriaLabel: 'giftcard.balance.popin.form.submit.cta.aria.label',
        numbersHelpCloseCta: 'giftcard.balance.popin.numbers.help.close.cta',
        numbersHelpDescription: 'Le numéro de votre carte cadeau CHANEL se trouve dans l\'e-mail transmis par votre expéditeur ou sur le verso de la carte s\'il s\'agit d\'une carte physique.',
        numbersHelpDescriptionUk: '',
        secondPopinTitle: 'Votre solde est de',
        popinSecondInformations: 'giftcard.balance.popin.second.information',
        balanceValidity: 'valable jusqu\'au',
        otherCardCta: 'Vérifier le solde d\'une autre carte',
        balanceSecondPopinAriaLabel: 'Votre solde'
    },
    giftCardConfirmationPopin: {
        closeBtnEgiftCard: 'Fermer la fenêtre Commander une carte cadeau',
        closeBtnContent: 'Fermer la fenêtre Commander ce produit',
        closeBtnOabService: 'Fermer commander un service',
        titleContent: 'COMMANDER CE PRODUIT',
        titleEGiftCard: 'COMMANDER UNE CARTE CADEAU',
        titleOabService: 'Commander un service',
        description1: 'Votre panier ne peut pas contenir une e-carte cadeau ainsi que d\'autres articles CHANEL.',
        descriptionOabService1: 'Votre panier ne peut pas contenir de service pour d’autres produits CHANEL.',
        descriptionContent: 'En continuant, le contenu de votre panier sera supprimé.',
        descriptionEGiftCard: 'En continuant, l\'e-carte cadeau sera supprimée de votre panier.',
        descriptionOabServiceContent: 'En continuant, vous acceptez que ce service soit retiré de votre panier.',
        confirmationCta: 'CONFIRMEZ',
        cancelCta: 'Annuler'
    },
    mixedCartCncConfirmationPopin: {
        'cnc.hd': {
            title: 'POUR VOTRE INFORMATION',
            closeLabel: 'Fermer',
            description1: 'Nous ne sommes actuellement pas en mesure de traiter les commandes des services Click & Collect et livraison à domicile en même temps.',
            description2: 'Remarque',
            continueCta: 'Confirmer et ajouter au panier',
            continueBtnXPath: 'btnContinueCNCProductAlert',
            cancelBtnXPath: 'btnCancelCNCProductAlert',
            cancelCta: 'Annuler'
        },
        'cnc.wfj': {
            title: 'Remarque :',
            closeLabel: 'Fermer',
            description1: 'Nous ne pouvons actuellement pas joindre ces produits à la même commande.',
            description2: 'Ajouter cette création à votre panier supprimera automatiquement tout ce qu\'il contient déjà.',
            continueCta: 'Ajouter à mon panier',
            continueBtnXPath: 'btnContinueCnDHDProductAlert',
            cancelBtnXPath: 'btnCancelCnDHDProductAlert',
            cancelCta: 'Annuler'
        },
        'wfj.fnb': {
            title: 'POUR VOTRE INFORMATION',
            closeLabel: 'Fermer',
            description1: 'Les pièces de l’Horlogerie et de la Joaillerie sont envoyées séparément des produits de soin, maquillage, parfums et lunettes. CHANEL vous invite donc à passer des commandes distinctes.',
            description2: 'En ajoutant cette pièce à votre panier vous enlèverez tous les autres produits déjà présents.',
            continueCta: 'Confirmer et ajouter au panier',
            continueBtnXPath: 'btnContinueHDProductAlert',
            cancelBtnXPath: 'btnCancelHDProductAlert',
            cancelCta: 'Annuler'
        },
        'hd.cnd': {
            title: 'Remarque :',
            closeLabel: 'Fermer',
            description1: 'Nous ne pouvons actuellement pas joindre ces produits à la même commande.',
            description2: 'Ajouter cette création à votre panier supprimera automatiquement tout ce qu\'il contient déjà.',
            continueCta: 'Ajouter à mon panier',
            continueBtnXPath: 'btnContinueCnDHDProductAlert',
            cancelBtnXPath: 'btnCancelCnDHDProductAlert',
            cancelCta: 'Annuler'
        },
        'psp.cnd': {
            title: '',
            closeLabel: 'Fermer',
            description1: '',
            description2: '',
            continueCta: 'Ajouter à mon panier',
            continueBtnXPath: 'btnContinuePSPProductAlert',
            cancelBtnXPath: 'btnCancelPSPProductAlert',
            cancelCta: 'Annuler'
        },
        'psp.psp': {
            title: '',
            closeLabel: 'Fermer',
            description1: '',
            description2: '',
            continueCta: 'Ajouter à mon panier',
            continueBtnXPath: 'btnContinuePSPProductAlert',
            cancelBtnXPath: 'btnCancelPSPProductAlert',
            cancelCta: 'Annuler'
        },
        titleClickAndCollect: 'POUR VOTRE INFORMATION',
        closeLabelclickAndCollect: 'Fermer',
        clickAndCollectDescription1: 'Nous ne sommes actuellement pas en mesure de traiter les commandes des services Click & Collect et livraison à domicile en même temps.',
        clickAndCollectDescription2: 'Remarque',
        titleHomeDelivery: 'POUR VOTRE INFORMATION',
        closeLabelHomeDelivery: 'Fermer',
        homeDeliveryDescription1: 'Les pièces de l’Horlogerie et de la Joaillerie sont envoyées séparément des produits de soin, maquillage, parfums et lunettes. CHANEL vous invite donc à passer des commandes distinctes.',
        homeDeliveryDescription2: 'En ajoutant cette pièce à votre panier vous enlèverez tous les autres produits déjà présents.',
        confirmationCta: 'Confirmer et ajouter au panier',
        cancelCta: 'Annuler'
    },
    kakaoWishList : {
        title : 'CHANEL',
        description: '',
        button: '',
    },
    excludedZipcodeRegex: {
        itCampione: 'CAMPIONE',
    },
    pageName: '',
    visitedMarket: 'FR', // IT'S COUNTRY CODE WHERE USER WHOULD ACCESS eg: /fr/ | /us/ | /es/ ...
    giftcardMessageMaxLines: '5',
    giftcardMessageMaxChars: '40',
    giftcardMessageLinesText: 'giftcard.message.max.chars',
    giftcardMessageMaxCharsText: 'giftcard.message.max.chars',
    giftcardMinAmount: '',
    giftcardMaxAmount: '',
    giftcardSendLaterEnable: '',
    gifcardCurrency: '',
    currentCurrency: '',
    loggedUserGigyaId: '',
    gigyaKApp: {
        getKAppSSO:'/fr/login/getKAppUserSSO',
        removeKAppSSO:'/fr/login/removeKAppSSO'
    },
    findBoutiqueCtaUrl: 'https://services.chanel.com/en_US/storelocator/opt/',
    myBoyfriendJsUrl: 'https://myboyfriend.chanel.com/widget/main.js',
    myBoyfriendCssUrl: 'https://myboyfriend.chanel.com/widget/main.css',
    myBoyfriendBackofficeUrl: 'https://myboyfriend.chanel.com',
    myBoyFriendCtaText: 'Personnaliser la montre',
    currentLanguage: 'fr_FR',
    storeLocatorUrl: '/fr/storelocator/',
    storeLocatorBaseUrl: 'https://services.chanel.com/',
    country: 'FR',
    region: 'eu',
    theme: '/_ui/responsive/theme-onechanel',
    fetchTimeout: '20000',
    CSRFToken: 'c5c75b5d-a144-4d13-8ee2-cfc3fed82f41',
    divisionFlag: '',
    crossDivisionalPage: '',
    enableChatLive: 'true',
    gigyaApiKey: '3_QKn2E38FHxMoE9yWTdvguJS5UsN-Bxhn7QcH8-5B-3h5Oha7F1DkT7s1iyBcWM8T',
    gigyaSdkUrl: 'https://cdns.eu1.gigya.com',
    gigyaLocale: 'fr',
    gigyaScriptUrl : 'https://cdns.eu1.gigya.com/js/gigya.js?apiKey=3_QKn2E38FHxMoE9yWTdvguJS5UsN-Bxhn7QcH8-5B-3h5Oha7F1DkT7s1iyBcWM8T&lang=fr',
    navigationType: 'CORE_NAVIGATION',
    forcePassword : 'false',
    googleMapKey: 'AIzaSyCNSC2tBQj4LvgOZhYbnPmOA9BvA1TS-eY', // it is a test key, we still need a Chanel provided Google API key
    googleMapVersion: '3.36',
    turntoKey: 'gjaJXjSiGzCwLqDsite',
    recaptchaCdn: 'https://www.google.com/recaptcha/api.js?onload=onloadCallback&render=explicit&hl={0}',
    gReCaptchaKey: '6Lelo7EUAAAAAIjuzww7agSxAzDXGUaM0PtoPax9',
    cloudinary: {
        host: '//www.chanel.com/emea/img/',
        defaultQuality: 'q_auto:good,f_auto,fl_lossy,dpr_1.2',
        customQuality: 'q_auto:good,fl_lossy,dpr_1.2,f_',
        greybackgroundQuality: 'e_brightness:-3',
        folder: 'prd-emea',
        srcFallback: '1920',
        defaultSrcFallBack: '960',
        assetPath: '/assets/media/product_default.png',
        assetSrcset: '788w',
        mobileAssetPath: '/assets/media/product_mobile_default.png',
        mobileAssetSrcset: '314w',
        srcset: '100,200',
        storiesSrcset: '335,384',
        helpSrcset: '90'
    },
    productId: '',
    paths: {
        icons: '/_ui/responsive/theme-onechanel/assets/',
        vto: '/_ui/responsive/theme-onechanel/assets/'
    },
    markets: {
        url: '/fr/yapi/markets/',
        checkoutUrl: '/fr/yapi/markets/checkout',
        popinComponent: '/fr/popinComponent'
    },
    cto: {
        dedicated: {
            rotate: 'Tournez votre appareil en mode portrait',
            removeCurrentShade: 'Supprimer la teinte actuelle',
            errorProduct: 'La teinte sélectionnée est indisponible. Veuillez en choisir une autre.',
            addToBag: 'AJOUTER AU PANIER',
            newFiltersHeading: 'Affiner la recherche',
            screenReaderText: 'Catégories produits',
            lips: 'lèvres',
            eyeshadows: 'ombres à paupières',
            eyeliners: 'eye-liners',
            noResults: 'Aucun résultat ne correspond aux filtres sélectionnés.',
            disclaimerText: '* Prix de vente suggéré.',
            disclaimerTextMoreInfo: 'En savoir plus',
            disclaimerTextTitle: 'En savoir plus sur le prix de vente suggéré',
            disclaimerTextPriceInfo: 'informations prix',
            addToWishlist : 'Ajouter à la liste de souhaits',
            removeFromWishlist : 'Supprimer de la liste de souhaits',
            newRemoveFilter : 'Réinitialiser les paramètres',
            categoryTransalation: 'Catégorie',
            finishScreenReaderText : 'Finitions',
            previousShades : 'Teintes précédentes',
            nextShades : 'Teintes suivantes',
            previousFinishes : 'Finitions précédentes',
            nextFinishes : 'Finitions suivantes',
            previousHarmonies : 'Harmonies précédentes',
            nextHarmonies : 'Harmonies suivantes',
            backtoShadeText : 'Retour à la liste des teintes',
            harmonyScreenReaderText : 'Harmonies',
            shadesAvailable : 'teintes disponibles',
            ctoText : 'Essayage virtuel Chanel',
            canvasText : 'L’essayage virtuel utilise la reconnaissance faciale et le mapping pour afficher une version tridimensionnelle des produits de maquillage Chanel sur votre visage via votre webcam.',
            iframeTitle : 'Reconnaissance facile et mapping',
            cameraText : 'Prenez une photo avec&nbsp;:',
            timerText : 'Compte à rebours',
            photoCaptureImageAltText : 'Votre photo',
            photoCaptureDownloadText : 'Téléchargez votre photo',
            photoCaptureShareText: 'Partagez votre image',
            photoCaptureBackText : 'Retour',
            enablePictureCTODedicatedPage: true,
            harmoniesHeading: 'Harmonies',
            addToCartMessage: 'Ce produit a été ajouté à votre panier.',
            saveAndShare: 'Sauvegarder le look',
            closeSaveAndShare: 'Options fermer, sauvegarder et partager',
            saveToAccount: 'Sauvegardé',
            saveAccount: 'SAUVEGARDER',
            download: 'Télécharger',
            enableSaveAndShareCTODedicated: false
        }
    },
    autoSuggestUrl: 'http://query.published.live1.fas.eu1.fredhopperservices.com/chanel_eu_w1',
    pages: {
        account: {
            login : '/fr/login',
            addressBook: '/fr/account/addresses/',
            addresses: {
                eu: {
                    modal: {
                        setAsDefault: {
                            title: 'Définir cette adresse comme adresse par défaut pour :',
                            label: 'account.eu.addresses.setAsDefault.modal.label',
                            cross: 'account.eu.addresses.setAsDefault.modal.button.cross'
                        }
                    }
                }
            }
        },
        bridal:{
            requestBtnTitle: ''
        }
    },
    webservices: {
        account: {
            extend: '/fr/yapi/session/extend',
            invalidate: '/fr/yapi/session/invalidate',
            loginUrl: '/fr/gigyaraas/login',
            logoutUrl: '/fr/sign-out',
            settingsUrl: '/fr/yapi/config',
            wishlistUrl: '/fr/yapi/wishlists',
            ordersUrl: '/fr/yapi/orders',
            userUrl: '/fr/yapi/customer/me',
            subscribePreferences: '/fr/account/preferences-subscribe',
            preferencesErrorAOI: '',
            preferencesErrorCC: '',
            preferencesOpt: '/fr/account/preferences-opt/',
            userMedias: '/fr/account/user-medias/',
            withdrawAccount : '/fr/account/withdraw-account',
            deleteUserAccount: '/fr/account/delete-account',
            resendOtp:'/fr/login/otpGenForAccountRegistration',
            generateOtp:'/fr/login/send/otp',
            getOtp: '/fr/login/otpGenForAccountRegistration',
            loginPage:'/fr/login/',
            notifyLoginUrl:'/fr/gigyaraas/notifyLogin',
            yandexUrl: '/fr/yandex/register',
            setDefaultAddressUrl:'/fr/account/setDefaultCommunicationAddress/',
            intellipostUrl: '/fr/account/orders/details//getReturnAuthorizationCodeFromIntelipost',
            authCode: '',
            prepaidShippingError: '',

            progressiveProfiling : '/fr/progressive/profiling/login/',
            getCsrfToken : '/fr/yapi/session/csrf-token',
            address: {
                delete: '/fr/gigya/deleteAddress',
                removeCommunicationAddress: '/fr/account/gigya/deleteAddress',
                editCommunicationAddress : '/fr/account/edit-address',
                setAsDefault: '/fr/yapi/addressbook/setDefaultAddress/',
                replaceCommunicationAddress : '/fr/account/updateCommunicationAddress',
                eu: {
                    setAsDefault: {
                        get: '/fr/yapi/addressbook/getDefaultPopinEU/',
                        save: '/fr/yapi/addressbook/setDefaultAddress'
                    }
                },
                cn: {
                    addcity: '/fr/cn-address/region/',
                    adddistrict: '/fr/cn-address/city/',
                    choose : '',
                }
            },
            paymentInfo: {
                setDefault: '/fr/account/set-default-payment-details',
                delete: '/fr/account/remove-payment-method'
            },
            isValidEmail: '/fr/yapi/email/validate/',
            isValidMobilePhone: '/fr/yapi/phone/ismobile/',
            isValidCpf: '/fr/yapi/cpf/validate/',
            apacSubscription:`/fr/newsletter/popup/apac`,
            capAdresse: {
                config: {
                    url: '/fr/yapi/addressbook/forms',
                    countriesWithFlagUrl: '/fr/yapi/addressbook/countriesWithSuggestionFlag',
                    communicationUrl: '/fr/account/communicationForms',
                    comCountriesWithFlagUrl: '/fr/account/comCountriesWithSuggestionFlag'
                }
            },
            experian: {
                enabled : 'false',
                suggestions: {
                    url: '/fr/yapi/experian/addressSuggestion',
                    method: 'POST',
                    headers: {
                        'Accept': 'application/json',
                        'Content-Type': 'application/json'
                    }
                },
                format: {
                    url: '/fr/yapi/experian/addressFormat',
                    method: 'POST',
                    headers: {
                        'Accept': 'application/json',
                        'Content-Type': 'application/json'
                    }
                }
            },
            precisely: {
                url: '/fr/yapi/precisely/addressSuggestion',
                method: 'POST',
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': 'application/json'
                }
            },
            suggestions: {
                url: '/fr/yapi/addressbook/addressSearchForEURegion',
                method: 'POST',
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': 'application/json'
                }
            },
            modal: {
                addAnAddress: {
                    label: 'ANNULER CE FORMULAIRE ?',
                    message: 'Votre adresse n’a pas été sauvegardée. Voulez-vous vraiment fermer ce formulaire ?',
                    ok: 'Poursuivre l’édition',
                    ko: 'Voir mes adresses',
                    suggetionMsg: ''
                }
            },
            captchaErrorMessage: 'Pour vous connecter, veuillez confirmer que vous n’êtes pas un robot. Besoin d’aide ? Veuillez contacter notre Service client. Appelez le \u003Ca class=\"link is-underline-small\" href=\"tel:\"\u003E\u003Cspan\u003E\u003C\/span\u003E\u003C\/a\u003E ou utilisez nos services \u003Ca class=\"link is-underline-small\" href=\"https:\/\/services.chanel.com\/fr_\/contact\" target=\"_blank\"\u003E\u003Cspan\u003Ee-mail\u003C\/span\u003E\u003C\/a\u003E.',
            captchaErrorMessageGb: 'Pour vous connecter, veuillez confirmer que vous n’êtes pas un robot. Besoin d’aide ? Veuillez contacter notre Service client. Appelez le \u003Ca class=\"link is-underline-small\" href=\"tel:\"\u003E\u003Cspan\u003E\u003C\/span\u003E\u003C\/a\u003E ou utilisez nos services \u003Ca class=\"link is-underline-small\" href=\"https:\/\/services.chanel.com\/fr_\/contact\" target=\"_blank\"\u003E\u003Cspan\u003Ee-mail\u003C\/span\u003E\u003C\/a\u003E.',
            registerCaptchaErrorMessage: 'Vous pouvez contacter le Service Clients de CHANEL au \u003Ca class=\"link is-underline-small\" href=\"tel:\"\u003E\u003Cspan\u003E\u003C\/span\u003E\u003C\/a\u003E ou via \u003Ca class=\"link is-underline-small\" href=\"https:\/\/services.chanel.com\/fr_\/contact\" target=\"_blank\"\u003E\u003Cspan\u003Ee-mail\u003C\/span\u003E\u003C\/a\u003E si vous avez besoin daide lors de la création de votre compte.',
            deleteAccountModal: {
                ongoingOrder: {
                    label: 'Commandes en cours'
                },
                deleteSuccess: {
                    label: 'Compte supprimé'
                }
            }
        },
        cached: {
            header: '/fr/api/dynamic/status',
            plp: '/yapi/wishlist'
        },
        cart: {
            cartUrl: '/fr/cart',
            add: '/fr/cart/add',
            remove: '/fr/cart/deleteEntry',
            move: '/fr/cart/moveToWishlist',
            undo: '/fr/cart/undoMoveToWishlist',
            removeAllSamples: '/fr/cart/removeAllSamplesfromCart',
            addSample: '/fr/cart/addSampleToCart',
            removeSample: '/fr/cart/removeSamplefromCart',
            updateGiftMessage: '/fr/cart/updateGiftMessage',
            wrapType: '/fr/cart/addWrappingTypeInCart',
            personalization: '/fr/cart/addPersonalizationInCart',
            cartTitle: 'Panier',
            poscartTitle: 'Click & Collect',
            addAll:'/fr/cart/addall'
        },
        kakao: {
            key: 'd7758157b016bfd9ad32940ad12e6a28',
            imageUrl: 'https://image.e-news.chanel.com/lib/fe341570756404787d1c75/m/1/063650e2-eaba-47ec-94cb-5daf31eb5c06.png',
            url: '//developers.kakao.com/sdk/js/kakao.min.js'
        },
        applepay: {
            timeoutError : '',
            version: '3',
            validateMerchant: '/fr/applepay/validatemerchant',
            buynow: '/fr/buynow/add',
            buynowCancel: '/fr/buynow/applepay/cancel',
            applePayData: '/fr/applepay/setApplePayData',
            handle: {
                pdp: '/fr/applepay/express/response/handle',
                minicart: '/fr/applepay/express/response/handle',
                cart: '/fr/applepay/express/response/handle',
                checkout: '/fr/applepay/classic/response/handle'
            },
            cancel: {
                minicart: '/fr/applepay/express/cancel',
                cart: '/fr/applepay/express/cancel',
                pdp: '/fr/buynow/applepay/cancel'
            },
            setDeliveryAddress: '/fr/applepay/request/express/setdeliveryaddress',
            validateAddress: '/fr/yapi/applepay/address/validate',
            setDeliveryModes: '/fr/applepay/request/express/setdeliverymode',
            placeOrder: '/fr/applepay/placeorder'
        },
        livechat: {
            liveChatProvider: 'IADVIZE',
            liveChatClientIdentifier: '7087',
            liveChatProviderApiUrl: 'https://halc.iadvize.com/iadvize.js',
            liveChatEnabled: true,
            liveChatDeploymentId: '',
            liveChatScriptUrl: '',
            liveChatButtonId: '',
            happyTalkSiteId: '',
            happyTalkSiteName: '',
            happyTalkEndPoint: '',
            happyTalkCategoryId: '',
            happyTalkApiGo: '',
            happyTalkIsLogin: '',
            happyTalkUid: '',
            happyTalkUserGB: '',
            happyTalkTitle: '',
            happyTalkDivisionId: '',
            liveChatOptionHeading:''
        },
        checkout: {
            oabCheckoutUrl: '/fr/checkout/oab',
            checkoutUrl: '/fr/checkout',
            stockRelease: '/fr/stock/release',
            paymentError: '/fr/checkout/paymentError',
            addGiftCard: '/fr/checkout/payment/giftCard/add',
            removeGiftCard: '/fr/checkout/payment/giftCard/remove',
            giftCardPlaceOrder: '/fr/checkout/payment/giftCard/submit',
            threeDS2GiftCard: '/fr/checkout/payment/giftCard/response',
            threeDS2Response: '/fr/checkout/payment/creditcard/response',
            threeDS2ResponseLegacy: '/fr/checkout/sop/adyen/handle3DS2Response',
            fdkPlaceOrder: '/fr/checkout/firstdata/placeorder',
            placeOrderFromHistory: '/fr/checkout/multi/cn-summary/payNow',
            cnPlaceOrder: '/fr/checkout/multi/cn-summary/placeOrder',
            weChatPayStart: '/fr/checkout/payment/wechat/submit',
            fdkPopup: '/fr/checkout/firstdata/popup',
            codOperation: '/fr/editPayment/cod/',
            cnCheckPaymentStatus: '/fr/checkout/multi/cn-summary/checkPaymentResult/',
            weChatPaySubmit: '/fr/checkout/payment/wechat/response',
            validateExcludedPostalCode: '/fr/yapi/address/validate/postalcode',
            naverpay: '/fr/checkout/naverpay/placeorder'
        },

        cybersource: '/fr/cybersource/signature',
        wishlist: '/fr/wishlist',
        wishlistYapi: '/fr/yapi/wishlist/',
        pageload: '/fr/yapi/pageload/',
        dynamicDlCheckoutYapi: '/fr/yapi/dynamicdatalayer/Checkout',
        dynamicDlSkincareYapi: '/fr/yapi/dynamicdatalayer/SkincareRoutineComponent',
        giftCardBalance: '/fr/gift-card/check-balance',
        eGCGiftCardAvailableDates: '/fr/gift-card/date',
        checkForGiftCard: '/fr/cart/checkForEGiftCard',
        checkAddToBag: '/fr/cart/checkAddToBag',
        more: {
            addresses: '/fr/checkout/step2/getAddresses?start={0}&limit=5',
            billingAddresses: '/fr/checkout/step4/getAddresses?start={0}&limit=5',
            orders: '/fr/account/orders/?page=1',
            viewMoreActiveOrtClaims: '/fr/account/ort/viewMoreActiveOrtClaims?start=4&limit=4',
            viewMoreArchivedOrtClaims: '/fr/account/ort/viewMoreArchivedOrtClaims?start=4&limit=4'
        },
        toshiCartDataUrl: '/fr/checkout/step2/getToshiCartData',
        toshiLibraryUrl: 'https://integration-cdn.toshi.co/3.0/main.js',
        gmo: {
            apiKey: '9101492251005',
            gmoDeviceFingerUrl: 'https://ci-mpsnare.iovation.com/snare.js'
        },
        oab: {
            categoryList: '/fr/care-services/book-appointment/categories/',
            serviceList: '/fr/care-services/book-appointment/services/',
            boutiqueList: '/fr/care-services/boutiques/',
            boutiqueListByService: '/fr/care-services/book-appointment/boutiques-by-service/',
            boutiqueListByEvent: '/fr/care-services/book-appointment/boutiques-by-events/',
            dateSelection: '/fr/care-services/book-appointment/date/',
            eventDateSelection: '/fr/care-services/book-appointment/eventDate/',
            postAppointmentBooking: '/fr/care-services/book-appointment/booking/add/',
            postEventAppointmentBooking: '/fr/care-services/book-appointment/booking/addEvent/',
            categoryCollectionList: '/fr/care-services/book-appointment/questions/',
            confirmBooking: '/fr/care-services/book-appointment/booking/confirmation/',
            eventConfirmBooking: '/fr/care-services/book-appointment/booking/eventConfirmation/',
            
            login: '/fr/care-services/book-appointment/login',
            eventLogin: '/fr/care-services/book-appointment/eventLogin',
            confirmGuestBooking: '/fr/care-services/book-appointment/booking/guestConfirmation/',
            confirmGuestEventBooking: '/fr/care-services/book-appointment/booking/guestEventConfirmation/',
            confirmOABEventBooking: '/fr/care-services/book-appointment/booking/checkout/',
            confirmGuestResheduleBooking: '/fr/care-services/book-appointment/reschedule/confirm/'
        },
        ort : {
            forgotClaim: '/fr/repair-request/forgot-claim/'
        },
        pdp: {				variant: '/fr/p/loadVariant',
            createReview : '/fr/review/createreview',
            viewMoreReviews : '/fr/review/viewMoreReviews',
            upvote : '/fr/review/upvote',
            downvote : '/fr/review/downvote',
            sortReviewsBy : '/fr/review/sortReview',
            verifyPurchaser : '/fr/review/verifyPurchaser',
            preOrderToolTip : 'La pré-commande vous permet de réserver des articles qui ne sont pas encore en stock. Nous vous avertirons lorsque l’article pré-commandé sera disponible. Le montant payé ne sera prélevé que lors de l’expédition de l’article pré-commandé.',
            preOrderToolTipHelp : 'Qu’est-ce qu’une pré-commande ?',
            applePayTnCText : 'En cliquant sur Apple Pay, vous acceptez les {0}.',
            applePayDescription : 'Payer avec Apple Pay',
            applePayTnCLinkAria : 'Conditions d’utilisation d’Apple Pay',
            applePayTnCLinkText : 'Termes et Conditions',
            sizeErrorMsg        : 'Selectionnez une taille pour passer à l\'étape suivante',
            orderByPhoneDownLink : 'Consultez les conditions d’utilisation ci-dessous.',
            itemNotAvailableErrorMsg : 'Remarque : la disponibilité de cet article a été modifiée.'
        },
        notifyme: '/fr/notifyMe/notifySubmit',
        notifyMeByMobile: '/fr/notifyMe/notifySubmitByMobile',
        fetchNotifyMeUserDetails: '/fr/notifyMe/fetchNotifyMeUserDetails',
        product: '/fr/yapi/product/{0}',
        wishlist: {
            login: '/fr/login/'
        },
        bridal: {
            confirmation: '/fr/fine-jewelry/request-bridal-catalog/confirmation'
        }
    },
        sidePanel:{
             moreDetails:  'En savoir plus',
             productDetails: 'Détails du produit',
             shoppingBag: 'Panier'
     },
    locales: {
        account: {
            xpath: 'true',
            titleExtra : '| CHANEL',
            chanelMoiText: 'CHANEL & Moi',
            phoneNumberVerification: '',
            personalDetails: '',
            checkoutTitle: '',
            female: 'Femme',
            male: 'Homme',
            newcodeBtnText: '',
            wrongOtp: '',
            expiredOtp: '',
            optSendText: '',
            orderTitle: '',
            capAdresse: {
                select: 'Veuillez sélectionner dans la liste',
                zipCodeWithLetters: '["HR","LT","SE","LU"]',
                addressLine2Label: 'Apt, suite, étage, etc.',
                optionalText: '(facultatif)',
                mobile: {
                    modal: {
                        crossBtnLabel: 'Fermer'
                    }
                }
            },
            experian: {
                select: 'Veuillez sélectionner dans la liste',
            },
            orderCancelled: {
                confirmedMessage: 'Votre commande a été annulée',
                userEmail: 'Vous recevrez un e-mail de confirmation à l’adresse suivante :',
                continueBtn: 'Continuer',
                popUpMessage: 'Vous êtes sur le point d’annuler votre commande. Vos articles ne vous seront pas livrés et vous ne serez pas débité(e).',
                popUpMessageApple: 'Vous êtes sur le point d’annuler votre commande. Si vous annulez votre commande, vos articles ne vous seront pas livrés et vous serez remboursé(e).',
                popUpHeading: 'Annuler la commande',
                closeBtn: 'Fermer',
                btnConfirm: 'Confirmer l’annulation',
                closePopUp: 'Fermer la fenêtre Annuler la commande',
                closePopUpConfirmed: 'Fermer la fenêtre Votre commande a été annulée'
            },
            ecommCountries: ["US" ,"FR" ,"BG" ,"CH" ,"DK" ,"EE" ,"FI" ,"HR" ,"LT" ,"LV" ,"PL" ,"PT" ,"RO" ,"SE" ,"SI" ,"SK" ,"AT" ,"BE" ,"DE" ,"ES" ,"FR" ,"IT" ,"LU" ,"NL" ,"UA" ,"BR" ,"CA" ,"CN" ,"GB" ,"IL" ,"JP" ,"KR" ,"MY" ,"SG" ,"HK" ,"TW" ,"VN" ,"AU" ,"TH" ,"NO" ,"CZ" ,"AE" ,"SA" ,"KW" ],
            phoneCountryCodes: {
                "RU":"+7"
                ,
                "GR":"+30"
                ,
                "NL":"+31"
                ,
                "BE":"+32"
                ,
                "FR":"+33"
                ,
                "ES":"+34"
                ,
                "HU":"+36"
                ,
                "IT":"+39"
                ,
                "RO":"+40"
                ,
                "CH":"+41"
                ,
                "AT":"+43"
                ,
                "DK":"+45"
                ,
                "SE":"+46"
                ,
                "NO":"+47"
                ,
                "PL":"+48"
                ,
                "DE":"+49"
                ,
                "TR":"+90"
                ,
                "PT":"+351"
                ,
                "LU":"+352"
                ,
                "AL":"+355"
                ,
                "FI":"+358"
                ,
                "BG":"+359"
                ,
                "LT":"+370"
                ,
                "LV":"+371"
                ,
                "EE":"+372"
                ,
                "RS":"+381"
                ,
                "HR":"+385"
                ,
                "SI":"+386"
                ,
                "BA":"+387"
                ,
                "CZ":"+420"
                ,
                "SK":"+421"
                }
        },
        addToBagCta: {
            backorder: 'En cours de réapprovisionnement'
        },
        giftcard: {
            title: 'La carte cadeau | CHANEL',
            extra: 'giftcard.page.title.extra',
            step: 'giftcard.page.step',
            previousStep: 'étape précédente',
            activeStep: 'étape actuelle',
            nextStep: 'ÉTAPE SUIVANTE',
            addToBag: 'ajouter au panier'
        },
        menu: {
            welcome: 'Bienvenue',
            mainNavigation: 'Navigation principale',
            nameSuffix: ''
        },
        notifier: {
            addressDelete: {
                close: 'Fermer la fenêtre Notification de la suppression d’adresse',
                label: 'Notification de la suppression d’adresse'
            },
            request: {
                close: 'Fermer la fenêtre Notification de demande',
                label: 'Notification d’erreur',
                message: '\u003Cp\u003EUne erreur est survenue, veuillez réessayer plus tard\u003C\/p\u003E'
            },
            samples: {
                close: 'Fermer la fenêtre Notification d’échantillon',
                label: 'Notification d’échantillon',
                message: '\u003Cp\u003EAjoutez deux échantillons gratuits à votre commande pour continuer.\u003C\/p\u003E\u003Cul\u003E\u003Cli\u003E\u003Cbutton type=\"button\" class=\"link is-underline notifier__close\"\u003ESélectionnez des échantillons\u003C\/li\u003E\u003Cli\u003E\u003Cbutton type=\"submit\" class=\"link is-underline\" form=\"{0}\"\u003EContinuer sans échantillons\u003C\/li\u003E\u003C\/ul\u003E'
            },
            wishlist: {
                close: 'Fermer la fenêtre Notification de liste de souhaits',
                label: 'Notification de liste de souhaits'
            },
            accountDetails: {
                close: 'Fermer la fenêtre Notification d’informations personnelles',
                label: 'Notification d’informations personnelles'
            },
            preference: {
                close: 'Fermer la fenêtre Confirmation de mise à jour',
                label: 'Confirmation de mise à jour'
            },
            notifyMe: {
                close: 'Fermer la fenêtre d’erreur M’avertir',
                label: 'Fenêtre d’erreur M’avertir',
                message: 'notifier.notifyMe.message'
            },
            addAddress: {
                close: 'Fermer la fenêtre Notification d’informations personnelles',
                label: 'Notification d’informations personnelles',
                message: 'Vos modifications ont bien été sauvegardées.'
            }
        },
        modal: {
            cartMerge: {
                label: 'Alerte de fusion de paniers',
                close: 'Fermer la fenêtre Alerte de fusion de paniers',
                heading: 'Remarque',
                message: 'Remarque : votre panier a été fusionné. Certaines quantités ont été mises à jour en fonction des limites de commande autorisées et des stocks disponibles.',
                cta: 'Fermer'
            },
            passwordForcedUpdate: {
                label: 'Veuillez mettre à jour votre mot de passe',
                pattern: /(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,255}/
            },
            newsletterApacSubscription: {
                label:  `Abonnez-vous à l’actualité de la Maison Chanel`
            },
            message: {
                noLabel: 'No title is present in the modal. Use the "data-label" attribute on the visible title or pass the label using the "label" key when showing the modal.'
            },
            account: {
                session: {
                    isEnabled: true,
                    baseUrl: '/fr', // remove the last slash in the base url
                    timeout: {
                        label: 'Votre session est sur le point de se terminer',
                        close: 'Fermer Votre session est sur le point de se terminer',
                        message: 'Votre session est inactive depuis 29&nbsp;minutes.\u003Cbr \/\u003EPour des raisons de sécurité, vous serez automatiquement déconnecté(e) dans \u003Cspan id=\"countdown\"\u003E30\u003C\/span\u003E&nbsp;secondes.',
                        cta: 'Prolonger la session',
                        signout: 'Déconnexion'
                    },
                    loggedout: {
                        label: 'Vous avez été déconnecté(e)',
                        close: 'Fermer - vous allez être redirigé à la page d\'accueil',
                        message: 'Afin de protéger vos informations, vous avez été automatiquement déconnecté(e). Veuillez vous reconnecter pour poursuivre vos achats.',
                        cta: 'Connexion'
                    },
                    signin: {
                        label: 'Connexion',
                        close: 'Fermer connexion - vous allez être redirigé vers la page d\'accueil',
                        message: 'Connectez-vous à l’aide de votre adresse E-mail et de votre mot de passe.'
                    },
                    kakao: {
                        label:'',
                        isEnabled: false,
                        linkingAccountHeading:'',
                        linkingAccountParagraph: '',
                        linkingAccountEmailFieldLabel: '',
                        linkingAccountPasswordFieldLabel: '',
                        passwordRecovery:'Mot de passe oublié ?',
                        continueButton: ''
                    },
                    separator: ''
                }
            }
        },
        ooyalaVideoPlayer: {
            en: {
                fullscreen: {
                    label: 'Plein écran',
                    enabled: 'Plein écran activé',
                    disabled: 'Plein écran désactivé'
                },
                caption: {
                    label: 'Sous-titres',
                    enabled: 'Sous-titres activés',
                    disabled: 'Sous-titres désactivés'
                },
                playPause: {
                    label: 'Lecture et pause',
                    enabled: 'Lecture',
                    disabled: 'Pause'
                },
                volume: {
                    label: 'Volume',
                    enabled: 'Son activé',
                    disabled: 'Son désactivé'
                },
                HD: {
                    label: 'HD',
                    enabled: 'HD activée',
                    disabled: 'HD désactivée'
                },
                time: {
                    label: 'Modifier la durée de la vidéo'
                }
            },
            en_US: {
                fullscreen: {
                    label: 'Plein écran',
                    enabled: 'Plein écran activé',
                    disabled: 'Plein écran désactivé'
                },
                caption: {
                    label: 'Sous-titres',
                    enabled: 'Sous-titres activés',
                    disabled: 'Sous-titres désactivés'
                },
                playPause: {
                    label: 'Lecture et pause',
                    enabled: 'Lecture',
                    disabled: 'Pause'
                },
                volume: {
                    label: 'Volume',
                    enabled: 'Son activé',
                    disabled: 'Son désactivé'
                },
                HD: {
                    label: 'HD',
                    enabled: 'HD activée',
                    disabled: 'HD désactivée'
                },
                time: {
                    label: 'Modifier la durée de la vidéo'
                }
            }
        },
        errors: {
            form: {
                global: {
                    generic: {
                        base: '',
                        
                        invalidLoginID: 'Votre adresse e-mail ou mot de passe sont incorrects. Veuillez réessayer ou \u003Ca href=\"\/fr\/login\/forgotten-password\/\" rel=\"nofollow\"\u003E\u003Cspan\u003Eréinitialiser votre mot de passe\u003C\/span\u003E\u003C\/a\u003E.',
                        loginIdentifierExists: 'Il existe déjà un compte associé à cette adresse e-mail. Veuillez utiliser une adresse différente ou bien \u003Cbutton data-change-screen=\"gigya-login-screen\" type=\"button\" class=\"link is-underline\"\u003E\u003Cspan\u003Evous connecter\u003C\/span\u003E\u003C\/button\u003E.',
                        accountTemporarilyLockedOut: 'Remarque : trop de tentatives de connexion. Pour des raisons de sécurité, votre compte a été verrouillé. Veuillez \u003Ca href=\"\/fr\/login\/forgotten-password\/\" rel=\"nofollow\"\u003E\u003Cspan\u003Eréinitialiser votre mot de passe\u003C\/span\u003E\u003C\/a\u003E pour le déverrouiller.',
                        recoveryEmailExpired: 'Remarque : le lien de réinitialisation a expiré. Veuillez recommencer le processus de réinitialisation de votre mot de passe.',
                        pendingPasswordChange: 'Changement de mot de passe en attente'
                    },
                    shipping: {
                        base: 'Les informations que vous avez saisies ne sont pas correctes. Veuillez vérifier votre saisie avant de passer à la facturation.'
                    },
                    billing: {
                        base: 'Les informations que vous avez saisies ne sont pas correctes. Veuillez vérifier votre saisie avant de confirmer votre commande.'
                    },
                    samples: {
                        selectSamples: 'Veuillez sélectionner vos échantillons dans la liste ci-dessous.'
                    },
                    paymentMethodes: {
                        notAccepted: 'Ce mode de paiement n’est pas accepté. Veuillez utiliser une autre carte.'
                    },
                    giftcard: {
                        base: 'Un montant doit être défini',
                        minAmount: 'Le montant minimum est',
                        maxAmount: 'Le montant maximal est',
                        emptySenderInput: 'Indiquez le nom de l\'expéditeur',
                        emptyReceiverInput: 'Indiquez le nom du destinataire',
                        specialCharacterInput: 'Certains caractères ne peuvent pas s’afficher.',
                        emptyMailInput: 'Indiquez l\'email du destinataire',
                        emptyDateInput: '',
                        unavailableDate: '',
                        emptyCardNumber: 'Indiquez le numéro de carte',
                        emptyCardPin: 'Indiquez le code PIN',
                        wrongCardNumber: 'Ce numéro de carte n\'est pas valide',
                        wrongCardPin: 'Ce code Pin est erroné'
                    }
                },
                fields: {
                    guestUserEmail: 'Remarque : il existe déjà un compte associé à cette adresse e-mail',
                    base: 'Remarque : {label} est invalide',
                    ageLimitCheck: '',
                    phoneNumberDoesExist: '',
                    invalidLoginID: {
                        base: 'Remarque : votre adresse e-mail ou mot de passe est incorrect.'
                    },
                    
                    loginIDDoesNotExist: {
                        base: 'Aucun compte n’est associé à cette adresse e-mail. Veuillez utiliser une autre adresse ou bien \u003Ca href=\"\/fr\/login\/\" rel=\"nofollow\"\u003E\u003Cspan\u003Erevenir à la page de connexion\u003C\/span\u003E\u003C\/a\u003E.'
                    },
                    loginIdentifierExists: {
                        base: 'Remarque : il existe déjà un compte associé à cette adresse e-mail',
                        tel: ''
                    },
                    invalidMobilePhone: {
                        base: 'Remarque : le numéro de téléphone mobile doit contenir {lengthpattern} chiffres',
                        notAccepted: 'Remarque : utilisez un format de numéro de téléphone mobile valide'
                    },
                    invalidMobilePhoneLength: {
                        base: 'Remarque : le numéro de téléphone mobile doit contenir {lengthpattern} chiffres'
                    },
                    valueMissing: {
                        base: 'Remarque : {label} est obligatoire',
                        privacy: 'Remarque : vous devez accepter la politique de confidentialité.',
                        baseOABGuestConfirmation: 'Veuillez fournir votre {label}',
                        baseSerialNumber: 'Le numéro de série est requis',
                        notice: ''
                    },
                    badInput: {
                        base: 'Remarque : {label} est invalide',
                        password: 'Remarque : votre mot de passe doit contenir au moins 8 caractères, dont une majuscule, une minuscule et un caractère alphanumérique.',
                        email: 'Remarque : utilisez une adresse e-mail valide, par exemple nom@mail.com'
                    },
                    typeMismatch: {
                        base: 'Remarque : {label} est invalide',
                    },
                    tooShort: {
                        base: 'Remarque : {label} est trop court (min. {min} car.)'
                    },
                    reviewTooShort: {
                        base: 'Remarque : l’avis est trop court (min. 10 car.)'
                    },
                    sameEmailAddress:  'Remarque : la nouvelle adresse e-mail est identique à celle utilisée actuellement',
                    tooLong: {
                        base: 'Remarque : {label} est trop long (max. {max} car.)',
                        textarea: 'Votre message dépasse les 0 caractères autorisés.'
                    },
                    patternMismatch: {
                        base: 'Remarque : {label} est invalide',
                        password: 'Remarque : votre mot de passe doit contenir au moins 8 caractères, dont une majuscule, une minuscule et un caractère alphanumérique.',
                        name: 'Remarque : {label} ne doit pas contenir de chiffres ou caractères spéciaux, à l’exception du tiret, du point, de l’espace et de l’apostrophe',
                        latinizedName:'Remarque&nbsp;: {label} n\'accepte que les caractères de langue anglaise et latine et ne doit pas contenir de chiffres ou de caractères spéciaux.',
                        email: 'Remarque : utilisez une adresse e-mail valide, par exemple nom@mail.com',
                        notifyEmail: 'form.error.invalid.notifyEmail',
                        loginUserName: '',
                        textarea: 'Remarque : certains caractères ne sont pas compatibles. Veuillez vérifier votre message personnalisé.',
                        toshiMode: '',
                        otp: '',
                        zipcode: '',
                        serialPatternError: 'Nous n\'avons pas pu identifier le numéro de série de votre sac à main.',
                        postcodeError: '',
                        cpfError: '',
                        cpfNonUniqueError: '',
                        userExists: '',
                        wrongOtpError: '',
                        expiredOtpError: '',
                        postcodecheckoutError: '',
                        provincecheckoutError: '',
                        autocomplete: {
                            unknown: 'Remarque : nous ne reconnaissons pas votre ville, veuillez vérifier et utiliser la liste de suggestions',
                            unselect: 'Remarque : pour vérifier votre adresse vous devez sélectionner une ville dans la liste de suggestion',
                            incomplete: 'Remarque : vous devez entrer un nombre minimal de caractères pour faire apparaître une suggestion'
                        }
                    },
                    errorDataTest: {
                        titleCode: 'lblTitleErrorMessage_NewsLetter',
                        email: 'lblEmailErrorMessage_NewsLetter',
                        firstName: 'lblFirstNameErrorMessage_NewsLetter',
                        lastName: 'lblLastNameErrorMessage_NewsLetter',
                        phoneNumber: 'lblPhoneNumberErrorMessage_NewsLetter',
                        newsletterCheckbox:'lblPrivacyPolicyCheckBoxErrorMessage_NewsLetter'
                    },
                    regexInputLanguages: {
                        hkzh: '^[_\u4e00-\u9eff\s\w+( +\w+),.\'-]+$',
                        tw: '^[_\u4e00-\u9eff\s\w+( +\w+),.\'-]+$',
                        th: '^[\-a-zA-Z\_\u0E00-\u0E7F\s\w+( +\w+),.\'-]+$',
                        vn: '^[a-zA-ZÃ¡ÂºÂ®Ã¡ÂºÂ°Ã¡ÂºÂ²Ã¡ÂºÂ´Ã¡ÂºÂ¶ÃâÃ¡ÂºÂ¤Ã¡ÂºÂ¦Ã¡ÂºÂ¨Ã¡ÂºÂªÃ¡ÂºÂ¬ÃâÃï¿½Ãâ¬ÃÆÃ¡ÂºÂ¢Ã¡ÂºÂ Ãï¿½Ã¡ÂºÂ¾Ã¡Â»â¬Ã¡Â»âÃ¡Â»âÃ¡Â»â ÃÅ Ãâ°ÃËÃ¡ÂºÂºÃ¡ÂºÂ¼Ã¡ÂºÂ¸Ãï¿½ÃÅÃ¡Â»ËÃÂ¨Ã¡Â»Å Ã¡Â»ï¿½Ã¡Â»âÃ¡Â»âÃ¡Â»âÃ¡Â»ËÃâÃ¡Â»Å¡Ã¡Â»ÅÃ¡Â»Å¾Ã¡Â»Â Ã¡Â»Â¢ÃÂ ÃâÃâÃâ¢Ã¡Â»Å½Ã¡Â»ÅÃ¡Â»Â¨Ã¡Â»ÂªÃ¡Â»Â¬Ã¡Â»Â®Ã¡Â»Â°ÃÂ¯ÃÅ¡Ãâ¢Ã¡Â»Â¦ÃÂ¨Ã¡Â»Â¤Ãï¿½Ã¡Â»Â²Ã¡Â»Â¶Ã¡Â»Â¸Ã¡Â»Â´,.\'-\w+( +\w+)]+$',
                    },
                    langMismatch: {
                        base: 'Remarque : seuls les caractères anglais sont acceptés'
                    },
                    excludedZipCode: {
                        base: 'Remarque : nous ne livrons pas dans la commune correspondant à ce code postal'
                    },
                    giftMessageNotAllowed: 'Certains caractères ne peuvent pas s’afficher.'
                },
                addons : {
                    ort: {
                        email:{
                            patternMismatch: 'Attention: utiliser une adresse email valide de type nom@mail.com',
                            valueMissing: 'Attention: l’email est obligatoire',
                        },
                        claimID:{
                            valueMissing: 'Attention: le numéro de requête est requis'
                        },
                        phoneClaimId:{
                            valueMissing: 'Attention: le numéro de requête est requis'
                        },
                        phoneNumber: 'Remarque : Le numéro de téléphone est requis.',
                        prefixPhoneNumber:{
                            patternMismatch: 'Remarque : L\'indicatif pays est requis.'
                        }
                    }
                }
            }
        },
        plp: {
            refinedTitle: 'vue filtrée',
            priceFilter: 'tridiv_variant_price_france',
            close: 'Fermer les filtres et accéder aux résultats'
        },
        pdp: {
            variantLabel: 'Variantes disponibles',
            zoomLayerLabel: 'Image taille réelle',
            zoomLayerBtn: 'Fermer la version agrandie de l\'image. Pour la déplacer, faites-la glisser à l’aide de votre souris ou de votre doigt, utilisez les flèches ou cliquez\/appuyez dessus',
            zoomLayerBtnLook: 'Fermer la version agrandie de l’image - Pour la déplacer, faites défiler à l’aide de votre souris ou de votre doigt, ou bien utilisez les touches fléchées',
            zoomSize: '3500',
            zoomAltSeeFull: '- voir la version taille réelle',
            close: 'Fermer',
        },
        questionsAndAnswers : {
            bestAnswerText: 'Expert beauté :'
        },
        wishlist: {
            title: 'Liste de souhaits',
            singleItem: 'élément',
            multipleItems: 'éléments',
            empty: 'Liste de souhaits – Vide | CHANEL',
            pageTitle: 'Liste de souhaits | CHANEL'
        },
        cart: {
            title: 'Panier',
            singleItem: 'élément',
            multipleItems: 'éléments',
            applePay: {
                type: 'final',
                lineItems: {
                    subtotal: {
                        label: 'SOUS-TOTAL'
                    },
                    shipping: {
                        label: 'LIVRAISON'
                    },
                    taxes: {
                        label: 'TAXES',
                        'basket.page.totals.netTax': 'Taxes',
                        'basket.page.totals.estimateTax': 'Taxe estimée',
                        'basket.page.totals.taxIncluded': 'TVA incluse'
                    }
                },
                total: {
                    label: 'CHANEL'
                }
            }
        },
        axisLabel: {
            active: '- actif'
        },
        vto: {
            canvasLabel: 'L’essayage virtuel utilise la reconnaissance faciale et le mapping pour afficher une version tridimensionnelle des lunettes sur votre visage via votre webcam.',
            closeButtonLabel: 'Fermer l’essayage virtuel',
            tryOn: 'Essayer',
            quickAddToBagLabel: 'Ajouter rapidement au panier',
            addedToBagLabel: 'Ajouté à votre panier',
            permissionDenied: 'Votre webcam n’est pas connectée. Pour utiliser l’option essayage virtuel, veuillez autoriser l’accès à votre webcam.',
            iframe: 'iframe technique',
            unavailable: 'Produit indisponible'
        },
        opc: {
            applePay: {
                regex: {
                    poBoxPattern: '(p(\.|-|ost)?\s*o\.?(-|ffice)?\s*)?(box|b[^a-z])(\s|-)?\d*',
                    postalCode: '^\\d{5}((?:[-\\s]\\d{4})|(\\d{4}))?$',
                    emailPattern: '\\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}\\b',
                    phoneNumberPattern: '^(\\+1)?[-.\\s]?\\(?(\\d{3,3})[)-.\\s]{0,2}(\\d{3,3})[-.\\s]?(\\d{4,4})$'
                },
                errors: {
                    email: 'Utilisez une adresse e-mail valide, par exemple nom@mail.com.',
                    state: 'État invalide',
                    country: 'La facturation n’est assurée que vers France.',
                    country_shipping: 'La livraison n’est assurée que vers France.',
                    zip: 'Code postal invalide',
                    zip_exclusion: 'Nous ne livrons pas dans la commune correspondant à ce code postal',
                    poBox: 'Il n’est actuellement pas possible de choisir l’option livraison vers une boîte postale sur chanel.com avec Apple Pay. Veuillez sélectionner une nouvelle adresse de livraison.',
                    city: 'Lieu invalide',
                    address: 'Adresse invalide',
                    phoneNumber: 'Téléphone invalide',
                    firstname: 'Le prénom est requis',
                    lastname: 'Le nom est requis',
                    mobileNumber: 'Numéro de téléphone mobile invalide',
                    locality: 'Lieu invalide'
                },
                type: 'final',
                lineItems: {
                    subtotal: {
                        label: 'SOUS-TOTAL'
                    },
                    shipping: {
                        label: 'LIVRAISON'
                    },
                    taxes: {
                        label: 'TAXES'
                    }
                },
                total: {
                    label: 'CHANEL'
                }
            },
            customError: {
                termsAndCondition: 'Remarque : vous devez accepter les conditions d’utilisation.'
            },
            countryChange: {
                deliveryCountry: 'Pays de livraison',
                currentlyOnlineBoutique: 'Vous explorez actuellement la boutique en ligne CHANEL {0}.',
                changeLocationDescription: 'Si vous souhaitez que votre commande soit expédiée dans un autre pays, cliquez ci-dessous. Changer d’emplacement peut affecter la disponibilité, le prix, les taxes et options de livraison associées à vos articles.',
                changeYourLocation: 'Changer de pays',
                cartMessage:'Si vous sélectionnez cet emplacement, vos articles seront supprimés. Finalisez votre achat avant de changer d’emplacement ou ajoutez de nouveau ces articles à votre panier depuis la boutique en ligne associée à votre nouvel emplacement.',
                closeChangeDeliveryCountry: 'Fermer la fenêtre Changer de pays de livraison',
                defaultOption: 'Sélectionnez votre pays',
                submit: 'valider'
            },
            threeDS2Auth: {
                closethreeDS2Auth: 'Fermer la fenêtre Authentifier le paiement',
            }
        }
    },
    loadingMessage: 'Chargement en cours',
    popups: {
        'address-add': '/fr/checkout/step2/addAddress',
        'billing-address-add': '/fr/checkout/step4/addBillingAddress',
        'address-edit': '/fr/checkout/step2/editAddress',
        'billing-address-edit': '/fr/checkout/step4/editBillingAddress',
        'card-edit': '/fr/checkout/step4/editCard',
        'mini-cart': '/fr/cart/rollover/MiniCart',
        'cart-dl': '/fr/yapi/dynamicdatalayer/MiniCart',
        'quickview': '/fr/p/showQuickView',
        'shareWishlist': '/fr/wishlist/share',
        'searchDeliveryMode': 'yapi/cart/supportedDeliveryModes',
        'checkZipCode': 'yapi/cart/checkZipCode',
        'personalizationViewDetails': '/fr/cart/personalizationViewDetails',
        shipping: '/fr/cart/display',
        samples: '/fr/cart/sample/details',
        tax: '/fr/cart/display',
        staticOverlay: '/fr/staticOverlay',
        panelInfo: '/fr/cart/displayInfoPanel',
        listOfPOSDataForCnC:'/fr/cart/listOfPOSDataForCnC',
        displayFindInBoutiqueList:'/fr/cart/displayFindInBoutiqueList'
    },
    externalAssets: {
        akamaiMediaPlayerScript: 'https://amp.chanel.com/bundles/app/amp/amp.premier.js',
        akamaiMediaPlayerTheme: 'https://amp.chanel.com/bundles/app/amp/amp.premier.css',
        appointmentBrickworkScript: 'https://chanel.brickworksoftware.com/render/widgets?domElementId={_domelement_}&startWith=location&serviceId={_serviceid_}&locationId={_storeid_}',
        appointmentBrickworkCancelScript: 'https://chanel.brickworksoftware.com/render/widgets?showDashboard=true&dashdomElementId=bwWidget',
        appointmentTulipScript: 'https://us-appointmentbooking.chanel.com/render/widgets/booking-min.js',
        hlsScript: 'https://amp.chanel.com/bundles/app/resources/js/hls.min.js',
        chanelMediaPlayerScript: 'https://amp.chanel.com/bundles/app/dist/js/prod2.js',
        chanelMediaPlayerTheme: 'https://amp.chanel.com/bundles/app/dist/css/theme.css',
        turntoWidgetMainScript : 'https://static.www.turnto.com/traServer4_3/trajs/gjaJXjSiGzCwLqDsite/tra.js',
        turntoWidgetProductScript : 'https://static.www.turnto.com/sitedata/gjaJXjSiGzCwLqDsite/v4_3//d/itemjs',
        turntoWidgetStylesheet : 'https://static.www.turnto.com/tra4_3/tra.css',
        turntoWidgetQARRStylesheet : '/_ui/responsive/theme-onechanel/assets/turnto/css/turnto_combined.css?v=3.35.5',
    },
    dl: {
        event: 'uaevent',
        all: {
            event: 'niuserevent',
        },
        account: {
            title: 'compte',
            create: 'création',
            login: 'connexion',
            user: {
                logged: 'connecté(e)',
                notLogged: 'non connecté(e)'
            }
        },
        cart: {
            moveToWishlist: {
                ea: 'déplacer vers la liste de souhaits',
                ec: 'supprimer du panier'
            },
            removeProduct: {
                ea: 'supprimer',
                ec: 'supprimer du panier'
            },
            quantityChange: {
                ea: {
                    ok: 'panier',
                    ko: 'quantité modifiée'
                },
                ec: {
                    ok: 'ajouter au panier',
                    ko: 'supprimer du panier'
                }
            },
            pdp: {
                ea: 'page produit',
                ec: 'ajouter au panier'
            },
            plp: {
            }
        },
        wishlist: {
            share: {
                ec: 'Partager la liste de souhaits'
            }
        },
        chat: {
            ec: 'Discussion en direct',
            message: {
                sent: {
                    ea: 'message envoyé'
                },
                received: {
                    ea: 'message reçu'
                }
            }
        },
        callCTA: {
            url: '/fr/contact/call'
        },
        pdp: {
            eventAction: {
                zoom: 'Picture zoom',
                size: 'Size',
                color: ' Color',
                type: 'Type',
                qa: 'Q&A tab open',
                quantityUpdate: 'Quantité mise à jour',
                callForAvailability: 'call for availability',
                contactAnAdvisor: 'contact an advisor'
            },
            vto: {
                open: {
                    ec: 'product interaction',
                    ea: 'virtual try-on open'
                },
                close: {
                    ec: 'product interaction',
                    ea: 'virtual try-on closed'
                },
                modelChange: {
                    ec: ' vto',
                    ea: 'change model'
                },
                takePhoto: {
                    ec: 'vto',
                    ea: 'take photo'
                }
            }
        },
        opc: {
            event: 'virtualPageview',
            funnel: 'trier',
            steps: {
                login: 'Connexion',
                shipping: 'livraison',
                billing: 'facturation',
                confirmation: 'page de confirmation'
            },
            notification: {
                samples: {
                    employee: 'Vos échantillons ont été supprimés. Veuillez noter que les employés ne peuvent pas bénéficier d’échantillons lorsqu’ils passent commande avec leur compte employé.'
                }
            },
            paymentMethod: {
                selected: 'Votre carte est une',
                title: 'modes de paiement'
            },
            deliveryMethod: {
                method: 'mode de livraison',
                cnc: 'click & collect',
                errors:{
                    inValidDate: 'dl.opc.deliveryMethod.errors.invalidDate',
                    unavailableDate:'dl.opc.deliveryMethod.errors.unavailableDate',
                    emptyDate:''
                }
            },
            guest: 'invité(e)',
            loginCustomer: 'identifiant client',
            numberSubmitted: 'Votre numéro a bien été envoyé',
            signUpCta: 'S’inscrire'
        },
        sl: { // Store Locator
            ec: 'trouver une boutique',
            footer: {
                ea: 'cliquer',
                el: 'bas de page'
            },
            megaMenu: {
                ea: 'cliquer',
                el: 'menu'
            },
            burgerMenu: {
                ea: 'cliquer',
                el: 'menu burger'
            },
            pdp: {
                ec: 'interaction produit',
                ea: 'trouver une boutique'
            }
        },
        contactUs: {
            pdp: {
                ea: 'Nous contacter'
            }
        }
    },
    responsiveHeader: true,
    facecakeProps: {
        isFacecakeMockupEnabled: false,
        tryOnUrl: "https://chanel-glasses.facecake.com/try-on",
        sampleProductIds: [1234567,9876543]
    },
    chanelandmoiPLP: {
        chanelwarrantyTitle: 'Garantie CHANEL',
        chanelwarrantyParagraphOne: 'Une garantie de 5&nbsp;ans est proposée dès la date d’achat pour tous les sacs à main ou portefeuilles avec chaîne achetés depuis avril&nbsp;2021.',
        chanelwarrantyParagraphTwo: 'Cette garantie s’applique pour le remplacement de tout élément ou pour toute réparation nécessaire sur les sacs à main et portefeuilles avec chaîne CHANEL, sous réserve d’une utilisation adéquate. Elle est valable uniquement sous présentation d’une preuve d’achat dans l’une de nos boutiques.',
        chanelwarrantyParagraphThree: 'Votre boutique reste à votre disposition pour toute question relative à cette garantie.',
        chanelwarrantyParagraphUrlText: 'Voir toutes les Conditions Générales de Garantie',
        chanelrestoringTitle: 'Service de Restauration CHANEL',
        chanelrestoringParagraphOne: 'Seule la Maison CHANEL peut restaurer ses créations tout en garantissant leur intégrité.',
        chanelrestoringParagraphTwo: 'Ce service s’applique dans un premier temps aux iconiques sacs à main en cuir noir CHANEL. En fonction de sa condition et après un examen méticuleux, votre sac est confié à nos artisans spécialistes dans nos ateliers. Il y sera traité avec la même minutie que lors de sa création.',
        chanelrestoringParagraphThree: 'Votre boutique reste à votre disposition pour toute question relative à ce service.',
        chanelrestoringsubTitle: '5&nbsp;conseils d’entretien',
        chanelrestoringsubTitleSubtext: 'Vous trouverez ci-dessous cinq conseils et gestes à adopter pour prendre soin de votre sac CHANEL.',
        chanelrestoringLabelOne: 'Port',
        chanelrestoringLabelTwo: 'Protection',
        chanelrestoringLabelThree: 'Entretien',
        chanelrestoringLabelFour: 'Rangement',
        chanelrestoringLabelFive: 'Appréciation',
        chanelrestoringLabeltextOne: 'Afin de préserver les lignes élégantes de votre sac à main, évitez de le surcharger. Pour minimiser le risque de dégorgement des couleurs sur le cuir ou les vêtements, évitez tout contact prolongé entre les pièces de couleur claire et sombre.',
        chanelrestoringLabeltextTwo: 'Évitez toute exposition prolongée au soleil, à la lumière artificielle et à l’humidité. Si votre sac est mouillé, séchez soigneusement la zone avec un chiffon absorbant non pelucheux.',
        chanelrestoringLabeltextThree: 'Utilisez un chiffon doux et évitez tout produit d’entretien qui pourrait dégrader la finition de votre sac à main. Pour réduire l’apparence des marques sur la surface du cuir d’agneau, frottez en effectuant un mouvement circulaire.',
        chanelrestoringLabeltextFour: 'Enveloppez les chaînes ou bandoulières dans du papier et rangez votre sac droit dans sa pochette d’origine.',
        chanelrestoringLabeltextFive: 'Appréciez la patine naturelle de votre sac à main. Jour après jour, elle révèle un nouvel aspect de sa beauté, de son histoire… et de la vôtre.',
        chanelwarrantyClose: 'Fermer la Garantie Chanel',
        chanelrestoringClose: 'Fermer les Services de Restauration Chanel',
    },
    gtmlicence: "GTM-KNZ4RBR"
}

window.config.vto = {
        labels: {
            canvasLabel: 'L’essayage virtuel utilise la reconnaissance faciale et le mapping pour afficher une version tridimensionnelle des lunettes sur votre visage via votre webcam.',
            closeButtonLabel: 'Fermer l’essayage virtuel',
            tryOn: 'Essayer',
            deniedTitle: 'Votre webcam n’est pas connectée',
            deniedMessage: 'Pour utiliser l’option essayage virtuel, veuillez autoriser l’accès à votre webcam',
            invalid: 'Nous vous invitons à tester un autre coloris.',
            quickAddToBagError: 'erreur ajouter rapidement au panier',
            error: 'Une erreur est survenue, veuillez réessayer plus tard',
            unavailableShade: 'Coloris indisponible',
            limitationError: 'Erreur de limitation',
            close: 'Fermer',
            viewDetails: 'Voir les détails',
            reducerErrorName: 'Erreur !',
            light: 'léger',
            intense: 'intense',
            shadeSwitch: 'Testez l’{0}intensité de le teinte {1}',
            screenReaderText: 'Intensités'
        },
        eyewear: {
            sdkPath: '/_ui/responsive/theme-onechanel/assets/',
            resolution: {
                desktop: '640x480',
                mobile: '640x480'
            },
            closeButtonLabel: 'Fermer l’essayage virtuel',
            onePair: 'Essayer une paire',
            twoPair: 'Essayer deux paires',
            seeOtherColors: 'Voir les autres coloris'
        },
        makeup: {
            closeButtonLabel: 'Fermer la fenêtre d’erreur de l’essayage virtuel',
            variantSelector : {
                selected: 'Variante choisie',
                next: 'Variante suivante',
                previous: 'Variante précédente',
            },
            enableCTOPicturePDP: true,
            enableSaveAndSharePDP: false
        }
    };

/*indow.startCapture = function() {
    console.log('VTO SDK is loaded')
    window.eyewearSDKLoaded = true
}*/
</script>
<script type="text/javascript" id="jsConfigSecond">
jsConfigSecond= {
    mapProvider: 'google',
    baiduMap: {
        key: 'L9NGc7sPC2i3z4nOUfEtPk5XWhxzdxpN',
        version: '1.0',
        type: 'webgl'
    },
    twilio: {
        invalidEmail: 'Veuillez entrer votre adresse e-mail',
        userEmail: 'Cette adresse email a déjà été utilisée pour se connecter',
        heading: 'Les Rendez-vous Chanel',
        subheadMobile: 'Votre rendez-vous',
        text: 'Beauty Chat',
        date: 'date',
        dateAt: 'à',
        invite: 'Nom',
        invitesText: 'INVITATIONS({0})',
        ariaLabelText: 'Liste des participants',
        identity: 'Identifiez-vous avec votre adresse e-mail',
        waitingRoomText: 'Lors de ce rendez-vous, découvrez les gestes essentiels et techniques d\'application des produits CHANEL avec votre conseiller beauté.',
        waitingRoomHeader: 'Votre rendez-vous démarrera bientôt. Merci de bien vouloir patienter',
        waitingRoomHeaderAccepted: 'Votre conseiller beauté est disponible pour commencer le rendez-vous.',
        waitingRoomFooterHeading:'Vos options audio et vidéo',
        waitingRoomFooterP1:'Au moment de rejoindre votre conseiller beauté, vous serez invité à autoriser la prise de son et la caméra.',
        waitingRoomFooterP2:'Vous pourrez activer ou désactiver votre micro et votre caméra à tout moment pendant la consultation.',
        waitingRoomFooterP3:'Un arrière plan virtuel est également à votre disposition si vous le souhaitez.',
        waitingRoomFooterP4:'Ce rendez-vous n\'est pas enregistré. Nous vous remercions de ne pas enregistrer ni diffuser d\'image de nos expert(e)s CHANEL',
        mediaInactiveMessage:'La caméra et le micro ne sont pas encore activés',
        demandMediaAccessCta:'Accorder l\'accès',
        rejoinCta:'Commencer',
        cameraDropdownLabel:'Caméra par défaut',
        microphoneDropdownLabel:'Microphone par défaut',
        cameraDropdownTitleSubText:'Inverser la caméra',
        microphoneDropdownTitleSubText:'changer le microphone',
        mediaDisclaimer:'Vous pourrez activer ou désactiver votre micro et votre caméra à tout moment pendant la consultation.',
        closeText:'Fermer',
        cameraOffText:'Désactiver la caméra',
        cameraOnText:'Activer la caméra',
        audioOffText:'Désactiver le micro',
        audioOnText:'Activer le micro',
        backgroundOffText:'Désactiver l\'arrière-plan',
        backgroundOnText:'Activer l\'arrière plan',
        consultationText:'En attente des autres participants',
        consultationLeave:'Quitter',
        consultationAriaLabel:'Votre rendez-vous',
        conMicPhOff:'désactiver le microphone',
        conMicPhOn:'activer microphone',
        conCamOff:'désactiver la caméra',
        conCamOn:'activer camera',
        conRevCamOff:'désactiver la caméra arrière',
        conRevCamOn:'Inverser la caméra',
        conChatOff:'désactiver le chat',
        conChatOn:'activer le chat',
        newChatMessage:'Nouveau message',
        conBgOff:'Sans arrière-plan',
        conBgOn:'Arrière-plan CHANEL',
        startCTA:'Commencer',
        conSharePrd:'Partager',
        conMoreFun:'plus de fonctionnalités',
        localVideoAriaLabel:'Aperçu de mon flux vidéo',
        remoteVideoAriaLabel:'Aperçu des participants',
        participantJoined:'Client(s) connecté(s)',
        participantWaiting:'Client(s) en attente',
        acceptBtn:'accepter',
        notifAriaLabelText:'notification de connexion du client',
        searchTabText:'Recherche',
        myListTabText:'Ma liste',
        searchMainText:'Rechercher un produit',
        searchInputLabel:'Rechercher un produit',
        submitSearchText:'Ok',
        submitSearchSRText:'Valider votre recherche',
        actionText:'en savoir plus',
        srActionText:'en savoir plus',
        leavePopinHeading:'Terminer le rendez-vous',
        leavePopinText:'Souhaitez-vous terminer le rendez-vous en cours ?',
        leavePopinBtnConfirm:'Terminer',
        leavePopinHeadingBA:'Terminer le rendez-vous',
        leavePopinTextBA:'Souhaitez-vous vraiment mettre fin au rendez-vous pour tous les participants ?',
        leavePopinBtnConfirmBA:'Oui',
        leavePopinBtnCancel:'Annuler',
        catalogFetchPro:'chargement des produits…',
        catalogProCount:'résultats pour',
        catalogNoPro:'Aucun article ne correspond à votre recherche',
        productInfoPopinHeading: 'Voir informations produit',
        productInfoPopinShareCtaText: 'Partager',
        productInfoDeleteCtaText: 'Supprimer',
        productInfoPopinAddToListCtaText: 'Ajouter à la liste',
        shadeDropdownAriaLabel: 'changer coloris',
        productRef: 'Réf.',
        shareProductText: 'Le produit a été partagé',
        deletePopinHeading:'Supprimer ce produit de la liste ?',
        deleteProductText:'Souhaitez-vous vraiment retirer ce produit de la liste des produits à partager ?',
        conButton:'Confirmer',
        canButton:'Annuler',
        confirmBtn:'Confirmer et retirer l’article de ma liste',
        cancelBtn:'Annuler et retourner à ma liste',

        thankYouHeaderMessage:'Merci !',
        loading:'Chargement',
        thankYouHeaderMessageUser:'CHANEL vous remercie,',
        thankYouMsgOne:'Merci de votre participation,',
        thankYouMsgTwo:'Vous avez ajouté',
        thankYouMsgThree:'produit(s) au panier',
        sharedProductInfo:'produits ont été partagés à vos invités pendant le rendez-vous.',
        sharedProductInfoUser:'Retrouvez ci-dessous les produits présentés lors de votre rendez-vous',
        addedProducts:'Ce produit a été ajouté au panier',
        userOrderBtn:'Voir le panier et commander',
        sharedMsg:'Les suggestions de votre conseiller beauté CHANEL',
        sharedMsgBA:'produits partagés',
        sharedProdCountText:'produits',
        returnBtnText:'RETOUR',
        hideBtnText:'Masquer',
        titleText:'Chat',
        sendBtnText:'Envoyer',
        hideChatAriaLabel:'Masquer le chat',
        backBtnAriaLabel:'Retour',
        headerText:'CHANEL',
        hostText:'Hôte',
        sharedText:'oc.consultation.sharedText ',
        addToCartCTA:'Ajouter au panier',
        chatBodyAriaLabel:'messages dans le chat',
        chatMsgInputTitle:'Écrivez votre message ici',
        chatMsgAuthorSpanTxt:'dit:',
        sendButtonAriaLabel:'Envoyer votre message',
        messageBodyHiddenTxt:'Action disponible :',
        productAddedText:'Le produit a été ajouté à votre panier',
        cartMsgSuccess:'Vous avez ajouté le produit à votre panier',
        cartMsgFail:'Le produit ne peut pas être ajouté à votre panier',
        chatProductClientMessage:'Votre conseiller beauté vous a partagé un produit :',
        chatProdBAMsgClient:'Vous avez partagé un produit avec le client',
        chatProdBAMsgClients:'Vous avez partagé un produit avec tous les clients',

        addToWishlist: 'Ajouter aux favoris',
        removeFromWishlist:'Retirer des favoris',
        sharedProductA11yText: 'Utilisez la liste des titres pour accéder rapidement à ce produit',

        noClientWaiting: 'Pas d’invité en attente',
        clientWaitingTxt: 'Clients en attente',
        clientJoinedTxt: 'Clients connectés',
        closeNotificationPopup: 'Fermer la notification de connexion du client',
        acceptAllTxt: 'Tout accepter',
        btnRemove: 'Bloquer',
        carouselPrev: 'Produit précédent',
        carouselNext: 'Produit suivant',
        carouselPager: 'sur',
        availableAct: '',
        nameRequiredError: 'Veuillez saisir un nom valide.',
        incorrectFormatError: 'Le nom ne doit pas contenir de chiffres ou caractères spéciaux, sauf tiret, point, espace et apostrophe.',
        selectedRoleError: 'Ce rôle n’est plus disponible.',
        mainBa: 'Expert(e) CHANEL',
        assistantBa: 'Co-animateur',
        screenShareA11y: 'Partage d’écran conseiller',
        screenShareStart: 'Partager l’écran',
        screenShareStop: 'Arrêter le partage',
        mcVideoAriaLabel: 'Aperçu de',
        prevLiveView: 'Aperçu précédent',
        nextLiveView: 'Aperçu suivant',
        muteA11yText: 'en sourdine',
        unMuteA11yText: 'son réactivé',
        removeParticipantLabel: 'Bloquer l’invité(e)',
        removeParticipantText: 'Souhaitez-vous vraiment retirer {0} de la présentation&nbsp;?',
    },
    customerVerification: {
            getJWTTokenUrl: '/fr/getJWTTokens/',
            deleteGigyaUserUrl: '/fr/deleteGigyaUser/',
            isZombieCustomerUrl: '/fr/isZombieCustomer/',
            verifyAccountBtnLabel: 'Vérifier le compte',
            createAccountTitle:'Suivre ma commande',
            createAccountBtnLbl:'Créer un compte',
            checkoutOrderConfirmationMsg:'Votre compte a bien été créé.',
            registerTitle: 'Connexion',
            retry: 'Veuillez réessayer dans',
            second: '29&nbsp;s',
            progressiveRegisterClose: 'Fermer le formulaire d’inscription évolutif',
            progressiveRegisterTitle: 'INFORMATIONS SUPPLÉMENTAIRES',
            verificationCodeError:{
               incorrectCode:'Le code renseigné est incorrect. Veuillez réessayer ou faire une demande d’envoi de nouveau code',
               generatedMultipleCodes:'Vous avez généré trop de codes.',
               emptyCode:'Veuillez entrer le code de sécurité reçu par e-mail. Si vous ne l’avez pas reçu, veuillez faire une demande d’envoi de nouveau code',
            },
            },
    customError: {
                consent: 'Please note : You must accept the withdrawal consent.',
                errorMsg: 'Il n’y a aucune boutique dans la ville recherchée. Si vous souhaitez prendre rendez-vous dans un autre pays, veuillez modifier votre emplacement.',
                errorMsgReq: 'Champ obligatoire, veuillez remplir ce champ.',
                errorMsgGeo: 'Adresse introuvable.',
                errorMsgGeo1: 'Le géocodage a échoué en raison de&nbsp;:',
                errorMsgGeo2: 'Vous devez désactiver la géolocalisation pour que votre navigateur utilise cette fonctionnalité.',
                errorMsgGeo3: 'Erreur&nbsp;: votre navigateur ne prend pas en charge la géolocalisation.',
                errorMsgPhone: '[FR-FR] Your phone number should start with a 4, please remove the 0 to continue with your booking.'
            },
    popinOAB: {
        popinAppointmentTitle : '',
        popinAppointmentDescription : '',
        popinAppointmentButton : '',
        popinAppointmentCloseButton : ''
    },
    livechat: {
        displayHelpButton: false,
        language: [],
        chatbotAvatarImgURL: '',
        defaultMinimizedText: '',
        disabledMinimizedText: '',
        loadingText: '',
        storageDomain: '',
        offlineSupportMinimizedText: '',
        entryFeature: '',
        baseLiveAgentContentURL: '',
        baseLiveAgentURL: '',
        eswLiveAgentDevName: '',
        isOfflineSupportEnabled: '',
        salesforceOrgId: '',
        communityURL: '',
        fallbackRouting: '',
        enabledFeatures: [],
        embeddedSvcURL1: '',
        eswSalesforceURL: '',
        extraPreChatFormDetails: [],
        srcURL: '',
        embeddedServiceLiveAgent: '',
        extraPrechatInfo: []
    },
    liveconnect: {
        liveconnectEnabled: `false`,
        liveconnectIntegrationId: ``,
        liveconnectClose : '',
        liveconnectPlaceholder: '',
        liveconnectIntroductionText: '',
        liveconnectWelcomeMessage:'',
        awayModePooledConversationMessage:'Bonjour {customerName}, nos conseillers ne sont pas disponibles pour le moment. Veuillez contacter le service client de CHANEL au 1 800 550 5355.',
        awayModeAssignedConversationMessage:'Bonjour {customerName}, votre conseiller n’est pas disponible pour le moment. Veuillez contacter le service client de CHANEL au 1 800 550 5355.',
        liveconnectOptionHeading:'',
        liveConnectAccountName: ``,
        liveConnectAccountkey: ``,
        liveConnectAdvisorIdleTime: ``,
        liveConnectAdvisorNotAvailableTime: ``
    },
    contactUsPanel: {
        phoneNumber: '0158376800'
    },
    checkTime: {
        configLiveChatPagesKR: 'fragrance,makeup,skincare',
        localTimeStart: '01:00',
        localTimeEnd: '07:00'
    },
    socialLogin: {
        weChatRegisterUrl:'/fr/wechat/silent/registration',
        weChatLoginUrl:'/fr/wechat/silent/login',
        weChatSocialLogin:'/fr/wechat/social/login',
        linkAccount:'/fr/wechat/linkAccounts',
        weChatUserExists: '/fr/wechat/weChatAccountExits',
        silentWechatLogin: '/fr/wechat/login'
    },
    account :{
        countrycode: 'Indicatif pays',
        otherphonenumber: 'Numéro de téléphone (facultatif)',
        success : 'Vos modifications ont bien été sauvegardées.',
        otherphone: 'account.update.profile.contact.other.otherphoneNumber',
        fieldsValidate: '/fr/yapi/fields/validate',
        additionalInfoFlag : 'true'
    },
    accountAuthOTP :{
        heading: 'Mon compte',
        verifyTitle: 'Vérifier votre compte',
        verifyMsg: 'CHANEL se soucie de la sécurité et de la confidentialité de vos données. Veuillez entrer le code envoyé à {0} pour vérifier votre adresse e-mail. Cette vérification est unique.',
        checkSpam: 'Remarque&nbsp;: vous devrez peut-être consulter vos spams.',
        codeNotReceived: 'Vous n’avez pas reçu de code&nbsp;?',
        codeResend: 'Renvoyer le code',
        manyAttempts: 'Vous avez généré trop de codes.',
        retryIn: 'Veuillez réessayer dans',
        sendAfter: 'Code envoyé',
        untilAsk: 'avant de pouvoir demander un nouveau code',
        second: '{0}&nbsp;secondes',
        cta: 'Vérifier le compte',
        guest: '',
        digits:{
            digit1: 'Premier chiffre',
            digit2: 'Deuxième chiffre',
            digit3: 'Troisième chiffre',
            digit4: 'Quatrième chiffre',
            digit5: 'Cinquième chiffre',
            digit6: 'Sixième chiffre'
        },
        errors:{
            required:'Veuillez entrer le code de sécurité reçu par e-mail. Si vous ne l’avez pas reçu, veuillez faire une demande d’envoi de nouveau code.',
            invalidCode:'Ce code de vérification est invalide. Veuillez réessayer.',
            expired:'Le code de vérification a expiré. Veuillez faire une demande d’envoi de nouveau code.',
            unknown:'Une erreur est survenue. Veuillez réessayer.',
        }
    },
    additionalPopin :{
        popinClose: '',
        additionalInfo: '',
        additionalPara: '',
        additionalTitle: '',
        selectTitle: '',
        chooseTitle: '',
        firstName: '',
        lastName: '',
        cpf: '',
        countryCode: 'Indicatif pays',
        addInfoTitle: 'NUMÉROS DE CONTACT',
        isUpdateAddInfo: '/fr/yapi/update-additional-info/',
    },
    popinProfiling: {
        title : '',
        ctaCreate : '',
        ctaContinue : ''
    },
    popinOTP: {
        title : '',
        close : '',
        message : '',
        renewMessage : '',
        renewResend : '',
        renewSent : '',
        cta : ''
    },
    wechat:{
        qrCodePopin:{
            title: '',
            close: '',
            altImgText : '',
            orderTitle : '',
            msg : '',
            guestMsg : ''
        },
        errPopin:{
            title: '',
            summary: '',
            description : ''
        },
        error:{
            cancelled: '',
            failed: ''
        },
        policyPopin: {
            title: 'wechat.registration.policy.title',
        },
        duplicateOrder: {
            description: ''
        },
        paymentRetryInterval: 3000
    },
    popUpMessages: {
      title: 'modes de paiement',
      description1: '',
      description2: '',
      description3: '',
      continueButtonText: '',
      aliPay: '',
      unionPay: '',
      wechatPay: '',
      close: 'Fermer'
    },
    optError : {
        hour: '',
        day: '',
        sendOtp: '',
        tokenhasbeenrevoked : '' ,
        limit: ''        
    },
    weChatUser : {
        existError: ''
    },
    userNotExist : {
        tel: ''
    },
    verification : {
        codeMessage: ''
    },      

    isVTOActive: false,
    isTryOnNewPosition: false,
    isBoutiqueApp: false,
    isNewInspiSearch21: true,
    isNewInspiEyewearSearch21: true,
    shouldOpenVTO:false,
    plpFilter: {
        'noFilterTransalation' : 'Résultat'
    },
    tryOnLegal: {
        cto: {
            isActive: true,
            message: `<div role="heading" aria-level="1"  id="privacyMessageHeader" class="try-on-legal-modal__title heading">Nous avons besoin d’accéder à votre image pour démarrer l’expérience «&nbsp;Virtual&nbsp;Try-On&nbsp;», que vous pouvez accepter en cliquant ci-dessous. </div><p class="try-on-legal-modal__description"> Nous ne conservons ni ne partageons ces informations, et votre image est automatiquement supprimée lorsque vous fermez la page «&nbsp;Virtual&nbsp;Try&nbsp;On&nbsp;». Vous pouvez consulter la <a class="link is-underline" href="https://services.chanel.com/fr_FR/privacy" target="_blank" rel="noopener noreferrer">  Politique de Confidentialité de CHANEL </a> pour plus d’informations sur l’utilisation de vos données personnelles par CHANEL. En cliquant sur «&nbsp;ACCEPTER&nbsp;», vous confirmez que vous acceptez également les Mentions Légales.  <a class="link is-underline" href="https://services.chanel.com/fr_FR/policies/legal" target="_blank" rel="noopener noreferrer">Mentions légales</a>.</p>`
        },
         vto: {
            isActive: true,
            message: `<div role="heading" aria-level="1"  id="privacyMessageHeader" class="try-on-legal-modal__title heading">Afin de démarrer l’expérience «&nbsp;Virtual&nbsp;Try-On&nbsp;», nous avons besoin d’accéder à votre image. Vous pouvez accepter en cliquant sur le bouton ci-dessous.</div><p class="try-on-legal-modal__description"> Nous ne conservons ni ne partageons ces informations, et votre image est automatiquement supprimée lorsque vous fermez la page «&nbsp;Virtual&nbsp;Try&nbsp;On&nbsp;». Vous pouvez consulter la  <a class="link is-underline" href="https://services.chanel.com/fr_FR/privacy" target="_blank" rel="noopener noreferrer"> Politique de Confidentialité de CHANEL </a> pour plus d’informations sur l’utilisation de vos données personnelles par CHANEL. En cliquant sur «&nbsp;ACCEPTER&nbsp;», vous confirmez que vous acceptez également les Mentions Légales. <a class="link is-underline" href="https://services.chanel.com/fr_FR/policies/legal" target="_blank" rel="noopener noreferrer">Mentions légales</a>.</p>`
        },
        wfj: {
            isActive: true
        },

        expirationTime: 4320,
        accept: 'ACCEPTER',
        decline: 'Refuser',
        legalInfo: 'Informations légales'
    },
    desktopViewMode:{
        showBurgerMenu: false
    },
    vto:{
                sdk: `https://plugins-media.perfectcorp.com/c3549/sdk.js?apiKey=X5b6EnTOhfBZz6ByEA9fgw==`,
            
        wristsdkID:`1021478`,
        labels: {
            wfj: {
                unavailable: 'Pièce non disponible',
                invalid: 'Nous vous invitons à tester une autre pièce',
                driveToStore: 'Découvrez-le en virtuel, retrouvez-le en boutique'
            }
        }
    },
    saveAndShare: {
        ctoPictureSquareFormat : false,
        successMessage: 'Votre look make up a été enregistré dans',
        successCloseBtn: 'Fermer Votre look make up a été enregistré',
        successMessageHyperlink: 'votre compte'
    },
    footer : {
        modal: {
            aria:{
                label:'QR code pour {0}'
            },
            image: {
                alt:'QR code pour accéder à Chanel {0}'
            },
            closeBtn: 'Fermer {0}',
        }
    },
    highContrastMode : {
      enable : 'Activer le mode contraste élevé',
      disable : 'Désactiver le mode contraste élevé',
      hcmFlag : true,
      excludePULS : true,
      popin : {
          title :'Contraste élevé',
          close : 'Fermer le mode contraste élevé',
          content : 'CHANEL prend à cœur l’accessibilité de son site web et apprécie tous vos commentaires. Nous vous invitons à fournir un maximum de détails concernant votre problème d’accessibilité afin que nous puissions le résoudre. Vous pouvez nous joindre par téléphone au <a class="link is-black is-underline" href="tel:1.800.550.0005"><span>1.800.550.0005</span></a> ou par <a href="https://services.chanel.com/en_US/contact" class="hcm-popin-email link is-underline js-open-email" rel="nofollow" target="_blank" data-event-label="email"><span>e-mail</span></a>.'
      }
    },
    product : {
      availability: '/fr/yapi/product/availability/{0}',
      sizeGuideUrl: 'https://ringsizeguide.chanel.com',
      packShotUrl: window.location.origin.replace('origin-','') + '/3dview',
      packShotCloseLabel: 'Fermer la vue 3D',
      packShotIframeTitle: 'Vue 3D'
    },
    apac: {
        apacAgeConsent: '',
        addcity: '/fr/hk-address/region/',
        adddistrict: '/fr/hk-address/city/',
        addsubdistrict: '/fr/hk-address/district/',
        postalcodedata: '/fr/yapi/sglocate/address-suggestion',
        postalcodeServerError: '',
        singpostCodeException: '',
        choose : '',
        popinNotifyMe: {
            popinDescriptionHK: '',
            popinCountryCodeLabelHK: '',
            popinMsgHK: '',
            popinMessageHK: ''
        }
    },
    middleEast: {
        me: {
            addProvince: '/fr/address/city/',
            addcity: '/fr/address/region/',
            adddistrict: '/fr/address/district/',
            choose : '',
        }
    },
    languagePopin: {
        languagePopinTitle : '',
        languagePopinDescription : '',
        languagePopinEnglishButton : '',
        languagePopinFrenchButton : ''
    },
    giftMessageConfiguration : {
                               },
    giftMessagePatternEU: /^([\u0100-\u017F\u0020\u0021\u0023-\u0026\u0028-\u003B\u003D\u003F-\u005A\u005C\u005E-\u007F\u00A0-\u00FF\u0400-\u045F\u037E-\u03CE\u2019\u1100-\u11FF\u200A-\u200C\uAC00-\uD7AF\u3130-\u318F\u4e00-\u9FFF\u30A0-\u30FF\u3040-\u309F\u3000-\u303F\uFF01\u003C\u0027\u0022\uFF1F\uFF0C\u0600-\u06FF\s]*)$/,
    legacyGiftMessageDisabled:'false',
    giftMessageRequiredCheckEnabled : false,
    alphabetRegex : {
                     LATIN : /[A-z\u00C0-\u00ff]|[\u0100-\u017F]/,
                     GREEK : /[\u0370-\u03FF]/,
                     CYRILLIC : /[\u0400-\u04FF]|[\u0500-\u052F]/,
                     ARABIC : /[\u0600-\u06FF]/,
                     JAPANESE : /[\u3040-\u309F]|[\u30A0-\u30FF]|[\uFF66-\uFF9F]|[\uFF61-\uFF65]|\uFFE5/,
                     CHINESE : /[\u2E80-\u2EFF\u2F00-\u2FDF\u31C1-\u31EF\u3300-㍗\u3200-\u32FF\u3400-\u4DB5\u9FB0-\u9FCC]|[\uFA0E\uFA0F\uFA11\uFA13\uFA14\uFA1F\uFA21\uFA23\uFA24\uFA27-\uFA29]|[\ud840-\ud868][\udc00-\udfff]|\ud869[\udc00-\uded6\udf00-\udfff]|[\ud86a-\ud86c][\udc00-\udfff]|\ud86d[\udc00-\udf34\udf40-\udfff]|\ud86e[\udc00-\udc1d]/,
                     KOREAN : /[\u3131-\u314e|\u314f-\u3163|\uac00-\ud7a3]/
                    },
    pdp: {
        quickAddToBag : {
            ctaLabel: '',
            enabled : 'false' === 'true'
        }
    },
    errorNotifierPopupEnabled : 'true',
    oab2:{
        qrCode: {
            msg: {
                wfj:'',
                fsh:''	
            },
            alt:'',
            close:''
        }
    },
    webServices2: {
        oab:{
            qrCode: '/fr/care-services/book-appointment/categories/qr-code'
        }
    },
    isMenuImageLazyLoaded : `true`
}

</script>
<script src="front_end_2/vendors.js"></script>
<script src="front_end_2/onechanel.js"></script><style></style>

<script type="text/javascript" nonce="" src="front_end_2/HicJZCk"></script>