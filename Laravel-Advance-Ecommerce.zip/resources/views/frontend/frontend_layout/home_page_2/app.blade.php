<!DOCTYPE html>
<!-- saved from url=(0026)https://www.chanel.com/fr/ -->
<html lang="fr-FR" region="EU" class=""><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <title>CHANEL Site Officiel : Mode, Parfum, Beauté, Horlogerie, Joaillerie | CHANEL</title>
@include('frontend.frontend_layout.home_page_2.meta')
		<script type="text/javascript">window.idzCustomData = {"privateaccess": false};</script><script type="text/javascript" async="" src="front_end_2/iadvize.js"></script><script async="" src="front_end_2/gtm.js"></script><script type="text/javascript" async="" src="front_end_2/gtm.js(1)"></script><script async="" src="front_end_2/gtm.js"></script><script type="text/javascript"> 
  const pageName = '' 
  function loadScript(scriptUrl) { 
    const scriptTag = document.createElement('script'); 
    scriptTag.setAttribute('src',scriptUrl); 
    scriptTag.setAttribute( 'type', "text/javascript" ); 
    document.head.appendChild(scriptTag); 
  } 

  function checkExistingPage(callback, url = "") {
    pageName == 'checkout' ? window.addEventListener("load",()=>callback(url) , {once:true}) : callback(url);
  }
</script> 
<!-- Start One Trust Code -->
<script> var OneTrust = { geolocationResponse: { stateCode: "FR", countryCode: "FR" }}; </script>
  <script type="text/javascript">
    function loadCookieScript() {
      const cookieTag = document.createElement('script'); 
      cookieTag.setAttribute( 'type', "text/javascript" ); 
      cookieTag.setAttribute('src',"https://cdn.cookielaw.org/scripttemplates/otSDKStub.js"); 
      cookieTag.setAttribute('data-language',"fr"); 
      cookieTag.setAttribute('charset',"UTF-8"); 
      cookieTag.setAttribute('async',"true"); 
      cookieTag.setAttribute('data-domain-script',"17a8718f-4328-48d8-a90f-2c1b1e33fc6a"); 
      document.head.appendChild(cookieTag); 
    }

    checkExistingPage(loadCookieScript, "")
    function OptanonWrapper() { }
  </script><script type="text/javascript" src="front_end_2/otSDKStub.js" data-language="fr" charset="UTF-8" async="true" data-domain-script="17a8718f-4328-48d8-a90f-2c1b1e33fc6a"></script>
<!-- End One Trust Code -->

 <script>
          function checkOnetrustActiveGroups(){
                var result = true;
                try{
                    const oneTrustCookieCheckType = 'STRICT_CONSENT';
                    const groupCheckRegex = RegExp('.*groups=[^&]*3:1.*');
                    const onetrustCookieValue = getOneTrustCookie();
                    if( 'NO_CHECK' != oneTrustCookieCheckType && ('FLEXIBLE_CONSENT' == oneTrustCookieCheckType && onetrustCookieValue && onetrustCookieValue.includes('groups')
                              || 'STRICT_CONSENT' == oneTrustCookieCheckType )){
                            // Check if we have the groupToCheck in the consents
                            result = groupCheckRegex.test(decodeURIComponent(onetrustCookieValue));
                    }
                } catch (error) {
                  // Inject monetate or Qubit if any exception
                }

                return result;
              }

              function getOneTrustCookie() {
                  const oneTrustCookieName = 'OptanonConsent';
                  var oneTrustCookieValue;
                  document.cookie.split(';').forEach(function(el) {
                    let [key,value] = el.split('=');
                    if(key.trim() == oneTrustCookieName){
                        oneTrustCookieValue = el.trim();
                    }
                  })
                  return oneTrustCookieValue;
              }
        </script>
    <!-- Start monetate tag. -->
              <script type="text/javascript">
                      window.chanelMonetateData = {"pageType":"main","categories":["lang_fr","country_FR"],"customVariables":[{"name":"lang","value":"fr"},{"name":"country","value":"FR"}],"pushCart":false}
                      window.srcMonetate = '//se.monetate.net/js/2/a-ed1b0fca/p/fr.chanel.com/entry.js';
                      if(window.srcMonetate && checkOnetrustActiveGroups()) {
                        window.monetateT = new Date().getTime();
                        checkExistingPage(loadScript, window.srcMonetate)
                      }
                  </script>
              <!-- End Monetate tag. -->
          <script type="text/javascript">
	window.__webpackIoChanelOutputPath = '/_ui/responsive/theme-onechanel/';
  </script>
  <link rel="preload" as="script" href="front_end_2/head.js">
  <link rel="preload" as="image" href="https://www.chanel.com/_ui/responsive/theme-onechanel/assets/icons.svg?v=3.35.5">
  
  <link rel="preconnect" href="https://fonts.chanel.com/" crossorigin="">
      <link rel="preload" as="style" href="front_end_2/xjf7bmk.css">
    <link rel="preload" type="text/css" as="style" href="front_end_2/main-fr_FR.css">
  <link rel="preload" as="script" href="front_end_2/vendors.js">
  <link rel="preload" as="script" href="front_end_2/onechanel.js">

  <link rel="manifest" href="https://www.chanel.com/_ui/responsive/theme-onechanel/assets/manifest.json?v=3.35.5">

  <link rel="icon" type="image/png" sizes="16x16" href="https://www.chanel.com/_ui/responsive/theme-onechanel/assets/media/favicon/16x16.png?v=3.35.5">
  <link rel="icon" type="image/png" sizes="32x32" href="https://www.chanel.com/_ui/responsive/theme-onechanel/assets/media/favicon/32x32.png?v=3.35.5">
  <link rel="icon" type="image/png" sizes="96x96" href="https://www.chanel.com/_ui/responsive/theme-onechanel/assets/media/favicon/96x96.png?v=3.35.5">
  <link rel="icon" type="image/png" sizes="192x192" href="https://www.chanel.com/_ui/responsive/theme-onechanel/assets/media/favicon/192x192.png?v=3.35.5">

  <link rel="apple-touch-icon" sizes="120x120" href="https://www.chanel.com/_ui/responsive/theme-onechanel/assets/media/favicon/120x120.png?v=3.35.5">
  <link rel="apple-touch-icon" sizes="152x152" href="https://www.chanel.com/_ui/responsive/theme-onechanel/assets/media/favicon/152x152.png?v=3.35.5">
  <link rel="apple-touch-icon" sizes="167x167" href="https://www.chanel.com/_ui/responsive/theme-onechanel/assets/media/favicon/167x167.png?v=3.35.5">
  <link rel="apple-touch-icon" sizes="180x180" href="https://www.chanel.com/_ui/responsive/theme-onechanel/assets/media/favicon/180x180.png?v=3.35.5">
  <link rel="alternate" hreflang="en-US" href="https://www.chanel.com/us/">
        <link rel="alternate" hreflang="ar-KW" href="https://www.chanel.com/kw/">
        <link rel="alternate" hreflang="en-EE" href="https://www.chanel.com/ee/">
        <link rel="alternate" hreflang="no-NO" href="https://www.chanel.com/no/">
        <link rel="alternate" hreflang="nl-BE" href="https://www.chanel.com/be-nl/">
        <link rel="alternate" hreflang="zh-CN" href="https://www.chanel.cn/zh_CN/">
        <link rel="alternate" hreflang="en-AL" href="https://www.chanel.com/al/">
        <link rel="alternate" hreflang="en-MY" href="https://www.chanel.com/my/">
        <link rel="alternate" hreflang="nl-NL" href="https://www.chanel.com/nl/">
        <link rel="alternate" hreflang="en-AU" href="https://www.chanel.com/au/">
        <link rel="alternate" hreflang="ja-JP" href="https://www.chanel.com/jp/">
        <link rel="alternate" hreflang="de-CH" href="https://www.chanel.com/ch-de/">
        <link rel="alternate" hreflang="en-RO" href="https://www.chanel.com/ro/">
        <link rel="alternate" hreflang="en-BA" href="https://www.chanel.com/ba/">
        <link rel="alternate" hreflang="en-RS" href="https://www.chanel.com/rs/">
        <link rel="alternate" hreflang="en-FI" href="https://www.chanel.com/fi/">
        <link rel="alternate" hreflang="cz-CZ" href="https://www.chanel.com/cz/">
        <link rel="alternate" hreflang="ar-QA" href="https://www.chanel.com/qa/">
        <link rel="alternate" hreflang="en-BG" href="https://www.chanel.com/bg/">
        <link rel="alternate" hreflang="fr-CA" href="https://www.chanel.com/ca-fr/">
        <link rel="alternate" hreflang="pl-PL" href="https://www.chanel.com/pl/">
        <link rel="alternate" hreflang="pt-PT" href="https://www.chanel.com/pt/">
        <link rel="alternate" hreflang="fr-BE" href="https://www.chanel.com/be-fr/">
        <link rel="alternate" hreflang="en-SE" href="https://www.chanel.com/se/">
        <link rel="alternate" hreflang="en-SG" href="https://www.chanel.com/sg/">
        <link rel="alternate" hreflang="it-CH" href="https://www.chanel.com/ch-it/">
        <link rel="alternate" hreflang="tr-TR" href="https://www.chanel.com/tr/">
        <link rel="alternate" hreflang="en-SI" href="https://www.chanel.com/si/">
        <link rel="alternate" hreflang="fr-FR" href="https://www.chanel.com/fr/">
        <link rel="alternate" hreflang="vi-VN" href="https://www.chanel.com/vn/">
        <link rel="alternate" hreflang="en-SK" href="https://www.chanel.com/sk/">
        <link rel="alternate" hreflang="en-GB" href="https://www.chanel.com/gb/">
        <link rel="alternate" hreflang="en-CA" href="https://www.chanel.com/ca-en/">
        <link rel="alternate" hreflang="x-default" href="https://www.chanel.com/">
        <link rel="alternate" hreflang="ar-AE" href="https://www.chanel.com/ae/">
        <link rel="alternate" hreflang="en-GR" href="https://www.chanel.com/gr/">
        <link rel="alternate" hreflang="de-AT" href="https://www.chanel.com/at/">
        <link rel="alternate" hreflang="fr-CH" href="https://www.chanel.com/ch-fr/">
        <link rel="alternate" hreflang="ar-SA" href="https://www.chanel.com/sa/">
        <link rel="alternate" hreflang="de-DE" href="https://www.chanel.com/de/">
        <link rel="alternate" hreflang="zh-TW" href="https://www.chanel.com/tw/">
        <link rel="alternate" hreflang="zh-HK" href="https://www.chanel.com/hk-zh/">
        <link rel="alternate" hreflang="ko-KR" href="https://www.chanel.com/kr/">
        <link rel="alternate" hreflang="en-HK" href="https://www.chanel.com/hk-en/">
        <link rel="alternate" hreflang="pt-BR" href="https://www.chanel.com/br/">
        <link rel="alternate" hreflang="es-ES" href="https://www.chanel.com/es/">
        <link rel="alternate" hreflang="en-DK" href="https://www.chanel.com/dk/">
        <link rel="alternate" hreflang="en-LT" href="https://www.chanel.com/lt/">
        <link rel="alternate" hreflang="es-MX" href="https://www.chanel.com/mx/">
        <link rel="alternate" hreflang="en-HR" href="https://www.chanel.com/hr/">
        <link rel="alternate" hreflang="en-LV" href="https://www.chanel.com/lv/">
        <link rel="alternate" hreflang="it-IT" href="https://www.chanel.com/it/">
        <link rel="alternate" hreflang="en-HU" href="https://www.chanel.com/hu/">
        <link rel="alternate" hreflang="ru-RU" href="https://www.chanel.com/ru/">
        <link rel="alternate" hreflang="es-AR" href="https://www.chanel.com/lx/">
        <link rel="alternate" hreflang="id-ID" href="https://www.chanel.com/id/">
        <link rel="alternate" hreflang="de-LU" href="https://www.chanel.com/lu-de/">
        <link rel="alternate" hreflang="fr-LU" href="https://www.chanel.com/lu-fr/">
        <link rel="alternate" hreflang="th-TH" href="https://www.chanel.com/th/">
        <meta name="msapplication-TileColor" content="#ffffff">
  <meta name="msapplication-TileImage" content="/_ui/responsive/theme-onechanel/assets/media/favicon/144x144.png?v=3.35.5">
  <meta name="msapplication-config" content="/_ui/responsive/theme-onechanel/assets/media/product_default.png/browserconfig.xml?v=3.35.5">
  <meta name="theme-color" content="#ffffff">

  <link rel="dns-prefetch" href="https://services.chanel.com/">
<link rel="canonical" href="https://www.chanel.com/fr/">
<script type="application/ld+json">
      {
        "@context": "http://schema.org",
        "@type": "Organization",
        "name": "CHANEL",
        "url": "https://www.chanel.com/fr/",
        "logo": "https://www.chanel.com/_ui/responsive/theme-onechanel/assets/media/favicon/192x192.png?v=3.35.5",
        "sameAs": [
          "https://www.facebook.com/chanel/",
          "https://twitter.com/CHANEL",
          "https://plus.google.com/+CHANEL",
          "https://www.youtube.com/user/CHANEL",
          "https://www.instagram.com/chanelofficial/"
        ]
      }

    </script>
  <script type="application/ld+json">
      {
        "@context": "http://schema.org",
        "@type": "Website",
        "name": "CHANEL",
        "alternateName": "CHANEL",
        "url": "https://www.chanel.com/fr/",
        "potentialAction": {
           "@type": "SearchAction",
           "target": "https://www.chanel.com/fr/search?text={search_term}",
           "query-input": "required name=search_term"
          }
      }
    </script>
  <!-- Breadcrumbs -->
  <!-- End Breadcrumbs -->

  <link rel="stylesheet" type="text/css" media="all" href="front_end_2/main-fr_FR.css">
<link rel="stylesheet" href="front_end_2/xjf7bmk.css">
    <script>
    //Fix for ONE-63591
    window.Typekit = {load: function(){console.warn('Typekit.load function was removed from project One')}};
  </script><style type="text/css" id="operaUserStyle"></style>

  <script type="text/javascript" src="front_end_2/jquery-3.6.0.min.js" defer=""></script>

  <script src="front_end_2/head.js" async=""></script>
  <script>
  const deleteKey = function(obj, key) {
    let res = Object.assign({}, obj)
    delete res[key]
    return res
  }

  var dataLayerGA = {
    "pageLoad":
    	
    	      deleteKey({"newsletter_optin":"newsletter_optout","region_chanel":"europe","privateSegment":"","email_sha256":"","searchType":"","page_type":"homepage","page_origin":"hybris","cartId":"0084171188","language":"fr_fr","locale":"fr_FR","eventLabel":"","userId":"","logged":"not logged","divisionFlag":"","page_name":"chanel official website: fashion, fragrance, beauty, watches, fine jewelry | chanel","client":"","userEmail":"","cartValue":"0.0","currencyCode":"EUR"},  {"newsletter_optin":"newsletter_optout","region_chanel":"europe","privateSegment":"","email_sha256":"","searchType":"","page_type":"homepage","page_origin":"hybris","cartId":"0084171188","language":"fr_fr","locale":"fr_FR","eventLabel":"","userId":"","logged":"not logged","divisionFlag":"","page_name":"chanel official website: fashion, fragrance, beauty, watches, fine jewelry | chanel","client":"","userEmail":"","cartValue":"0.0","currencyCode":"EUR"}.eventLabel ? '': 'eventLabel')
  		   ,
    "productList":{}
  };

      if((Object.keys({}).length > 0) && dataLayerGA) {
        dataLayerGA.wishListMultiplePageLoad = Object.assign({"newsletter_optin":"newsletter_optout","region_chanel":"europe","privateSegment":"","email_sha256":"","searchType":"","page_type":"homepage","page_origin":"hybris","cartId":"0084171188","language":"fr_fr","locale":"fr_FR","eventLabel":"","userId":"","logged":"not logged","divisionFlag":"","page_name":"chanel official website: fashion, fragrance, beauty, watches, fine jewelry | chanel","client":"","userEmail":"","cartValue":"0.0","currencyCode":"EUR"}, {})
        delete dataLayerGA.pageLoad.event
        delete dataLayerGA.pageLoad.eventCategory 
        delete dataLayerGA.pageLoad.eventAction 
        delete dataLayerGA.pageLoad.ecommerce 
      }
    </script>
<!-- Google Tag Manager -->
  <script>

  var hidden = undefined, visibilityChange = undefined, haveChanged = false

    if (typeof document.hidden !== "undefined") {
      hidden = "hidden"
      visibilityChange = "visibilitychange";
    } else if (typeof document.msHidden !== "undefined") {
      hidden = "msHidden";
      visibilityChange = "msvisibilitychange";
    } else if (typeof document.webkitHidden !== "undefined") {
      hidden = "webkitHidden";
      visibilityChange = "webkitvisibilitychange";
    }

    function handleVisibilityChange() {
      if ((!document.hidden || !window.dataLayer) && !haveChanged) {
        haveChanged = true
        if(window.localStorage.getItem("isGuestUser") && document.querySelector('.checkout .confirmation') && dataLayerGA['accountAction']){
          dataLayerGA['pageLoad']['funnel_type'] = 'guest'
        }

        window.dataLayer = [dataLayerGA['pageLoad']];
        
            (function (w, d, s, l, i) {
              w[l] = w[l] || [];
              w[l].push({
                'gtm.start': new Date().getTime(), event: 'gtm.js'
              });
              var f = d.getElementsByTagName(s)[0],
                j = d.createElement(s), dl = l != 'dataLayer' ? '&l=' + l : '';
              j.async = true;
              j.src = 'https://www.googletagmanager.com/gtm.js?id='+i+dl+ '';
              f.parentNode.insertBefore(j, f);
            })(window, document, 'script', 'dataLayer', 'GTM-KNZ4RBR');
      }
    }

    if (typeof document.addEventListener === "undefined" || typeof document.hidden !== "undefined") {
      document.addEventListener(visibilityChange, handleVisibilityChange, false)
      checkExistingPage(handleVisibilityChange, "")
    }

  </script>

  <!-- End Google Tag Manager -->



<script charset="utf-8" src="front_end_2/cto_oc_search_try-on.js"></script><script charset="utf-8" src="front_end_2/search.js"></script>

</head>

<body class="language-fr_FR - page-globalHomePage pageType-ContentPage template-pages-homePage-chanelAxisHomePage pageLabel-- smartedit-page-uid-globalHomePage smartedit-page-uuid-eyJpdGVtSWQiOiJnbG9iYWxIb21lUGFnZSIsImNhdGFsb2dJZCI6ImNoYW5lbENvbnRlbnRDYXRhbG9nIiwiY2F0YWxvZ1ZlcnNpb24iOiJPbmxpbmUifQ== smartedit-catalog-version-uuid-chanelContentCatalog/Online chrome">
<ul id="header-sr-links" class="is-sr-only skip-links">
  <li>
    <a class="link is-cta" id="sr-main-content" href="https://www.chanel.com/fr/#main" data-focus-target="#main">Contenu principal</a>
  </li>
  <li class="is-hidden-s-only is-hidden-m-only">
    <a class="link is-cta" id="sr-main-navigation" href="https://www.chanel.com/fr/#main-navigation" data-focus-target="#main-navigation">Navigation principale</a>
  </li>
  <li>
      <button data-event-category="header" type="button" class="enable-high-contrast link is-cta">
        <span class="hcmButtonLabel">Activer le mode contraste élevé</span> 
      </button>
    </li> 
  </ul>
<header role="banner" class="header js-header">
  
<div class="header__outer" style="translate: none; rotate: none; scale: none; transform: translate(0px, 0px);">
    <div class="header__inner js-header-line-context">
      
  <div class="header__level-one js-header-level-one" aria-hidden="false" style="translate: none; rotate: none; scale: none; transform: translate(0px, 0px);">
        <div class="nav container">
          <ul class="nav-left nav-left-one">
            <li>
              <button title="Menu - navigation principale" aria-haspopup="dialog" data-test="lnkMainNagation" class="button nav-item js-header-toggle is-hidden-l" style="translate: none; rotate: none; scale: none; transform: translate(0px, 0px);">
                
<svg data-test="" class="icon is-large  is-burger " focusable="false" viewBox="0 0 1 1" aria-hidden="true" xmlns:xlink="http://www.w3.org/1999/xlink">
  <use xlink:href="/_ui/responsive/theme-onechanel/assets/icons.svg?v=3.35.5#burger"></use>
</svg>

<span class="header__menu-label">Menu</span><span class="is-sr-only"> - navigation principale</span>
              </button>
            </li>
            <li class="is-hidden-l ">

            <button title="Rechercher" aria-haspopup="dialog" class="button nav-item js-search-button" data-test="btnSearch_Header" style="translate: none; rotate: none; scale: none; transform: translate(0px, 0px);">
                
<svg data-test="" class="icon is-large  is-search " focusable="false" viewBox="0 0 1 1" aria-hidden="true" xmlns:xlink="http://www.w3.org/1999/xlink">
  <use xlink:href="/_ui/responsive/theme-onechanel/assets/icons.svg?v=3.35.5#search"></use>
</svg>

    <span class="is-sr-only">Rechercher</span>
  
</button></li>
          </ul>

          <div class="nav-center">
            <div class="nav-item" style="translate: none; rotate: none; scale: none; transform: translate(0px, 0px);">
              <h1>
					
<img class="
logo_header" role="img" alt=" CHANEL" data-test="lnkLogo" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==">
<svg aria-hidden="true" class="logo" data-test="imgLogo" focusable="false" height="28" width="175" viewBox="0 0 175 28">
   <g fill="#000" fill-rule="evenodd">
      <path d="M20.655 17.726l4.565 2.615c-2.282 4.197-6.737 6.922-11.781 6.922C6.075 27.263 0 21.629 0 13.713S6.075.163 13.439.163c5.044 0 9.5 2.725 11.781 6.923L20.655 9.7c-1.326-2.725-4.013-4.381-7.216-4.381-4.603 0-8.1 3.423-8.1 8.394s3.497 8.395 8.1 8.395c3.203 0 5.89-1.657 7.216-4.382M49.705 26.6V15.554H36.818V26.6h-5.154V.826h5.154V10.4h12.887V.826h5.155V26.6h-5.155M79.603 15.922L74.926 5.061 70.25 15.922h9.353zM89.838 26.6h-5.634l-2.54-5.892H68.188l-2.54 5.892h-5.634L71.428.826h6.996L89.838 26.6zM113.586 26.6L99.778 6.313V26.6h-4.786V.826h6.812l11.598 17.084V.826h4.787V26.6h-4.603M128.129 26.6V.826h18.41v4.787h-13.624v5.523h11.782v4.786h-11.782v5.892h14.36V26.6h-19.146M155.56 26.6V.826h5.154v20.62h13.622V26.6H155.56"></path>
   </g>
</svg></h1>
    	</div>
          </div>
          <ul class="nav-right">
            <li class="is-hidden-s">
              
<button type="button" title="Rechercher" aria-haspopup="dialog" class="button nav-item is-hidden-s-only js-search-button" data-test="btnSearch_Header_Disabled" style="translate: none; rotate: none; scale: none; transform: translate(0px, 0px);">
    
<svg data-test="" class="icon is-large  is-search " focusable="false" viewBox="0 0 1 1" aria-hidden="true" xmlns:xlink="http://www.w3.org/1999/xlink">
  <use xlink:href="/_ui/responsive/theme-onechanel/assets/icons.svg?v=3.35.5#search"></use>
</svg>

    <span class="is-sr-only">Rechercher</span>
  
</button></li>
            <li class="is-hidden-s ">
              
	<a title="Mon compte" data-selector="on-myaccount-button-click" data-datalayer="{}" class="button nav-item is-hidden-s-only is-hidden-m-only js-datalayer" href="https://www.chanel.com/fr/login/" rel="nofollow" style="translate: none; rotate: none; scale: none; transform: translate(0px, 0px);">
			
<svg data-test="{}" class="icon is-large  is-account " focusable="false" viewBox="0 0 1 1" aria-hidden="true" xmlns:xlink="http://www.w3.org/1999/xlink">
  <use xlink:href="/_ui/responsive/theme-onechanel/assets/icons.svg?v=3.35.5#account"></use>
</svg>

    <span class="is-sr-only">Mon compte</span>
  
</a></li>
            <li>
              <a title="Liste De Souhaits" class="button nav-item wishlist js-wishlist-datalayer nav-wishlist-item" href="https://www.chanel.com/fr/wishlist/" rel="nofollow" data-test="wishlist-go-to" data-datalayer="{&quot;event&quot;:&quot;uaevent&quot;,&quot;eventCategory&quot;:&quot;header&quot;,&quot;eventAction&quot;:&quot;wishlist&quot;,&quot;eventLabel&quot;:&quot;&quot;}" style="translate: none; rotate: none; scale: none; transform: translate(0px, 0px);">
	
<svg data-test="" class="icon is-large  is-wishlist " focusable="false" viewBox="0 0 1 1" aria-hidden="true" xmlns:xlink="http://www.w3.org/1999/xlink">
  <use xlink:href="/_ui/responsive/theme-onechanel/assets/icons.svg?v=3.35.5#wishlist"></use>
</svg>

    <span class="is-sr-only">Liste de souhaits</span>
  
</a>
</li>
            <li>
                <button title="Panier" class="js-cart cart button nav-item" aria-haspopup="dialog" data-popup-query="componentUid=item1593532821958" data-popup-target="mini-cart" data-cart-count="0" data-test="btnCArt" data-modal-title="Panier" style="translate: none; rotate: none; scale: none; transform: translate(0px, 0px);">
  
<svg data-test="" class="icon is-large  is-cart " focusable="false" viewBox="0 0 1 1" aria-hidden="true" xmlns:xlink="http://www.w3.org/1999/xlink">
  <use xlink:href="/_ui/responsive/theme-onechanel/assets/icons.svg?v=3.35.5#cart"></use>
</svg>

<span class="is-sr-only">Panier</span>
  </button>
</li>
            </ul>
        </div>
      </div><div class="header__root js-header-root" data-signin-welcome="&lt;li id=&quot;signIn-register&quot; class=&quot;js-header-entry signIn-register js-signIn-register&quot; data-test=&quot;btnAccount&quot;&gt;
    &lt;a id=&quot;signIn-welcome-firstName&quot; href=&quot;/fr/login/&quot; class=&quot;group__item js-datalayer&quot; data-test=&quot;btnMyAccountLnk&quot;   data-selector=&quot;on-myaccount-button-click&quot; data-datalayer=&quot;{}&quot;&gt;
      
&lt;svg data-test=&quot;&quot;   class=&quot;icon is-large  is-pulled-right is-account &quot; focusable=&quot;false&quot; viewBox=&quot;0 0 1 1&quot; aria-hidden=&quot;true&quot;
     xmlns:xlink=&quot;http://www.w3.org/1999/xlink&quot;&gt;
  &lt;use xlink:href=&quot;/_ui/responsive/theme-onechanel/assets/icons.svg?v=3.35.5#account&quot; /&gt;
&lt;/svg&gt;

Mon compte&lt;/a&gt;
  &lt;/li&gt;" style="opacity: 1;" aria-hidden="false">
    <nav id="main-navigation" class="header__primary" role="navigation" aria-label="navigation principale">
      <div class="nav is-hidden-l">
        <div class="nav-left"></div>
        <div class="nav-right">
          <button class="nav-item button js-header-close js-mobile-header-close" type="button" tabindex="0">
            
<svg data-test="" class="icon is-medium  is-close " focusable="false" viewBox="0 0 1 1" aria-hidden="true" xmlns:xlink="http://www.w3.org/1999/xlink">
  <use xlink:href="/_ui/responsive/theme-onechanel/assets/icons.svg?v=3.35.5#close"></use>
</svg>

   
</button>
          </div>
      </div>

       <ul class="header__primary__links header__primary__links1" aria-labelledby="exclu_boutique_divisions">
        <li class="js-header-entry ">
		<a href="https://www.chanel.com/fr/haute-couture/" id="hauteCouture" data-axis-type="fashion" class="header__primary__button js-header-link " data-aria-label="Haute Couture" data-event-action="Haute Couture" aria-hidden="false">
            	<span data-test="lnkAxisCategory_hauteCouture">Haute Couture</span>
				
 

</a>
		
</li>
	<li class="js-header-entry ">
		<a href="https://www.chanel.com/fr/mode/" id="fashion" data-axis-type="fashion" class="header__primary__button js-header-link is-active" role="button" aria-haspopup="dialog" data-aria-label="Mode" data-event-action="Fashion" aria-hidden="false" aria-label="fashion - actif">
            	<span data-test="lnkAxisCategory_fashion">Mode</span>
				
 

</a>
 

</li>
	<li class="js-header-entry ">
		<a href="https://www.chanel.com/fr/haute-joaillerie/" id="highJewelry" data-axis-type="fashion" class="header__primary__button js-header-link " data-aria-label="Joaillerie" data-event-action="High Jewelry" aria-hidden="false">
            	<span data-test="lnkAxisCategory_highJewelry">Haute Joaillerie</span>
 

</a>
		
</li>
	<li class="js-header-entry ">
		<a href="https://www.chanel.com/fr/joaillerie/" id="jewelry" data-axis-type="fashion" class="header__primary__button js-header-link " role="button" aria-haspopup="dialog" data-aria-label="Joaillerie" data-event-action="Fine Jewelry" aria-hidden="false">
            	<span data-test="lnkAxisCategory_jewelry">Joaillerie</span>
				
 
</a>
		
 

</li>
	<li class="js-header-entry ">
		<a href="https://www.chanel.com/fr/horlogerie/" id="watches" data-axis-type="fashion" class="header__primary__button js-header-link " role="button" aria-haspopup="dialog" data-aria-label="Horlogerie" data-event-action="Watches" aria-hidden="false">
            	<span data-test="lnkAxisCategory_watches">HORLOGERIE</span>
				
 

</a>
		
  

</li>
	</ul>
      <p class="header__shop js-header-shop is-sr-only" id="available_online_divisions">Acheter en ligne</p>
        <ul class="header__primary__links header__primary__links2" aria-labelledby="available_online_divisions">
          <li class="js-header-entry ">
		<a href="https://www.chanel.com/fr/lunettes/" id="eyewear" data-axis-type="fashion" class="header__primary__button js-header-link " role="button" aria-haspopup="dialog" data-aria-label="Lunettes" data-event-action="Eyewear" aria-hidden="false">
            	<span data-test="lnkAxisCategory_eyewear">Lunettes</span>
				
 

</a>
		
 
</li>
	<li class="js-header-entry ">
		<a href="https://www.chanel.com/fr/parfums/" id="fragrance" data-axis-type="fashion" class="header__primary__button js-header-link " role="button" aria-haspopup="dialog" data-aria-label="Parfums" data-event-action="Fragrance" aria-hidden="false">
            	<span data-test="lnkAxisCategory_fragrance">Parfums</span>
				

</a>
		
</li>
	<li class="js-header-entry ">
		<a href="https://www.chanel.com/fr/maquillage/" id="makeup" data-axis-type="fashion" class="header__primary__button js-header-link " role="button" aria-haspopup="dialog" data-aria-label="Maquillage" data-event-action="Makeup" aria-hidden="false">
            	<span data-test="lnkAxisCategory_makeup">Maquillage</span>
		</a>
		
</li>
	<li class="js-header-entry ">
		<a href="https://www.chanel.com/fr/soins/" id="skincare" data-axis-type="fashion" class="header__primary__button js-header-link " role="button" aria-haspopup="dialog" data-aria-label="Soin" data-event-action="Skincare" aria-hidden="false">
            	<span data-test="lnkAxisCategory_skincare">Soin</span>
				
 

</a>


</li>
	</ul>
      <p class="is-sr-only" id="corporate_menu">Entreprise</p>
              <ul aria-labelledby="corporate_menu">
                <li class="js-header-entry ">
                  <a href="https://www.chanel.com/fr/" id="aboutChanel" class="header__primary__button js-header-link about-chanel about-chanel__margin" data-axis-type="" role="button" aria-haspopup="dialog" data-aria-label="menu.axis.aria.aboutChanel" data-event-action="About Chanel" aria-hidden="false">
                    <span data-test="lnkAxisCategory_aboutChanel">About Chanel</span>
                  </a>
                    </li>
              </ul>
            
        </nav>
  </div><span class="header__line js-header-line" style="opacity: 1;"></span>
</div>
  </div></header>

 @yield('main_content')



 </body>

<!-- Version : "3.35.5" --><!-- Generation date = "2023-03-05 15:41:50 UTC" --><!-- Generation duration = "552ms" -->
</html>