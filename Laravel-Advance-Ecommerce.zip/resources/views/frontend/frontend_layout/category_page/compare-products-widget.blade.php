<!-- COMPARE-->
<div class="sidebar-widget wow fadeInUp outer-top-vs">
<h3 class="section-title">Compare products</h3>
<div class="sidebar-widget-body">
    <div class="compare-report">
    <p>You have no <span>item(s)</span> to compare</p>
    </div>
    <!-- /.compare-report --> 
</div>
<!-- /.sidebar-widget-body --> 
</div>
<!-- /.sidebar-widget --> 
<!-- COMPARE: END --> 