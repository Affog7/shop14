<section class="section latest-blog outer-bottom-vs wow fadeInUp">
<h3 class="section-title">latest form blog</h3>
<div class="blog-slider-container outer-top-xs">
    <div class="owl-carousel blog-slider custom-carousel">
    <div class="item">
        <div class="blog-post">
        <div class="blog-post-image">
            <div class="image"> <a href="blog.html"><img src="{{ asset('frontend') }}/assets/images/blog-post/post1.jpg" alt=""></a> </div>
        </div>
        <!-- /.blog-post-image -->
        
        <div class="blog-post-info text-left">
            <h3 class="name"><a href="#">Voluptatem accusantium doloremque laudantium</a></h3>
            <span class="info">By Jone Doe &nbsp;|&nbsp; 21 March 2016 </span>
            <p class="text">Sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.</p>
            <a href="#" class="lnk btn btn-primary">Read more</a> </div>
        <!-- /.blog-post-info --> 
        
        </div>
        <!-- /.blog-post --> 
    </div>
    <!-- /.item -->
    
    <div class="item">
        <div class="blog-post">
        <div class="blog-post-image">
            <div class="image"> <a href="blog.html"><img src="{{ asset('frontend') }}/assets/images/blog-post/post2.jpg" alt=""></a> </div>
        </div>
        <!-- /.blog-post-image -->
        
        <div class="blog-post-info text-left">
            <h3 class="name"><a href="#">Dolorem eum fugiat quo voluptas nulla pariatur</a></h3>
            <span class="info">By Saraha Smith &nbsp;|&nbsp; 21 March 2016 </span>
            <p class="text">Sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.</p>
            <a href="#" class="lnk btn btn-primary">Read more</a> </div>
        <!-- /.blog-post-info --> 
        
        </div>
        <!-- /.blog-post --> 
    </div>
    <!-- /.item --> 
    
    <!-- /.item -->
    
    <div class="item">
        <div class="blog-post">
        <div class="blog-post-image">
            <div class="image"> <a href="blog.html"><img src="{{ asset('frontend') }}/assets/images/blog-post/post1.jpg" alt=""></a> </div>
        </div>
        <!-- /.blog-post-image -->
        
        <div class="blog-post-info text-left">
            <h3 class="name"><a href="#">Dolorem eum fugiat quo voluptas nulla pariatur</a></h3>
            <span class="info">By Saraha Smith &nbsp;|&nbsp; 21 March 2016 </span>
            <p class="text">Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium</p>
            <a href="#" class="lnk btn btn-primary">Read more</a> </div>
        <!-- /.blog-post-info --> 
        
        </div>
        <!-- /.blog-post --> 
    </div>
    <!-- /.item -->
    
    <div class="item">
        <div class="blog-post">
        <div class="blog-post-image">
            <div class="image"> <a href="blog.html"><img src="{{ asset('frontend') }}/assets/images/blog-post/post2.jpg" alt=""></a> </div>
        </div>
        <!-- /.blog-post-image -->
        
        <div class="blog-post-info text-left">
            <h3 class="name"><a href="#">Dolorem eum fugiat quo voluptas nulla pariatur</a></h3>
            <span class="info">By Saraha Smith &nbsp;|&nbsp; 21 March 2016 </span>
            <p class="text">Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium</p>
            <a href="#" class="lnk btn btn-primary">Read more</a> </div>
        <!-- /.blog-post-info --> 
        
        </div>
        <!-- /.blog-post --> 
    </div>
    <!-- /.item -->
    
    <div class="item">
        <div class="blog-post">
        <div class="blog-post-image">
            <div class="image"> <a href="blog.html"><img src="{{ asset('frontend') }}/assets/images/blog-post/post1.jpg" alt=""></a> </div>
        </div>
        <!-- /.blog-post-image -->
        
        <div class="blog-post-info text-left">
            <h3 class="name"><a href="#">Dolorem eum fugiat quo voluptas nulla pariatur</a></h3>
            <span class="info">By Saraha Smith &nbsp;|&nbsp; 21 March 2016 </span>
            <p class="text">Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium</p>
            <a href="#" class="lnk btn btn-primary">Read more</a> </div>
        <!-- /.blog-post-info --> 
        
        </div>
        <!-- /.blog-post --> 
    </div>
    <!-- /.item --> 
    
    </div>
    <!-- /.owl-carousel --> 
</div>
<!-- /.blog-slider-container --> 
</section>
<!-- /.section --> 