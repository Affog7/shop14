<div class="wide-banners wow fadeInUp outer-bottom-xs">
    <div class="row">
        <div class="col-md-7 col-sm-7">
            <div class="wide-banner cnt-strip">
                <div class="image"> <img class="img-responsive" src="{{ asset('frontend') }}/assets/images/banners/home-banner1.jpg" alt=""> </div>
            </div>
        <!-- /.wide-banner -->
        </div>
    <!-- /.col -->
    <div class="col-md-5 col-sm-5">
        <div class="wide-banner cnt-strip">
            <div class="image"> <img class="img-responsive" src="{{ asset('frontend') }}/assets/images/banners/home-banner2.jpg" alt=""> </div>
        </div>
    <!-- /.wide-banner -->
    </div>
    <!-- /.col -->
    </div>
<!-- /.row -->
</div>
<!-- /.wide-banners -->
