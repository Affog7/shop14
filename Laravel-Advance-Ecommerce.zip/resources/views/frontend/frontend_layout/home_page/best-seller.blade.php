<div class="best-deal wow fadeInUp outer-bottom-xs">
<h3 class="section-title">Best seller</h3>
<div class="sidebar-widget-body outer-top-xs">
    <div class="owl-carousel best-seller custom-carousel owl-theme outer-top-xs">
    <div class="item">
        <div class="products best-product">
        <div class="product">
            <div class="product-micro">
            <div class="row product-micro-row">
                <div class="col col-xs-5">
                <div class="product-image">
                    <div class="image"> <a href="#"> <img src="{{ asset('frontend') }}/assets/images/products/p20.jpg" alt=""> </a> </div>
                    <!-- /.image --> 
                    
                </div>
                <!-- /.product-image --> 
                </div>
                <!-- /.col -->
                <div class="col2 col-xs-7">
                <div class="product-info">
                    <h3 class="name"><a href="#">Floral Print Buttoned</a></h3>
                    <div class="rating rateit-small"></div>
                    <div class="product-price"> <span class="price"> $450.99 </span> </div>
                    <!-- /.product-price --> 
                    
                </div>
                </div>
                <!-- /.col --> 
            </div>
            <!-- /.product-micro-row --> 
            </div>
            <!-- /.product-micro --> 
            
        </div>
        <div class="product">
            <div class="product-micro">
            <div class="row product-micro-row">
                <div class="col col-xs-5">
                <div class="product-image">
                    <div class="image"> <a href="#"> <img src="{{ asset('frontend') }}/assets/images/products/p21.jpg" alt=""> </a> </div>
                    <!-- /.image --> 
                    
                </div>
                <!-- /.product-image --> 
                </div>
                <!-- /.col -->
                <div class="col2 col-xs-7">
                <div class="product-info">
                    <h3 class="name"><a href="#">Floral Print Buttoned</a></h3>
                    <div class="rating rateit-small"></div>
                    <div class="product-price"> <span class="price"> $450.99 </span> </div>
                    <!-- /.product-price --> 
                    
                </div>
                </div>
                <!-- /.col --> 
            </div>
            <!-- /.product-micro-row --> 
            </div>
            <!-- /.product-micro --> 
            
        </div>
        </div>
    </div>
    <div class="item">
        <div class="products best-product">
        <div class="product">
            <div class="product-micro">
            <div class="row product-micro-row">
                <div class="col col-xs-5">
                <div class="product-image">
                    <div class="image"> <a href="#"> <img src="{{ asset('frontend') }}/assets/images/products/p22.jpg" alt=""> </a> </div>
                    <!-- /.image --> 
                    
                </div>
                <!-- /.product-image --> 
                </div>
                <!-- /.col -->
                <div class="col2 col-xs-7">
                <div class="product-info">
                    <h3 class="name"><a href="#">Floral Print Buttoned</a></h3>
                    <div class="rating rateit-small"></div>
                    <div class="product-price"> <span class="price"> $450.99 </span> </div>
                    <!-- /.product-price --> 
                    
                </div>
                </div>
                <!-- /.col --> 
            </div>
            <!-- /.product-micro-row --> 
            </div>
            <!-- /.product-micro --> 
            
        </div>
        <div class="product">
            <div class="product-micro">
            <div class="row product-micro-row">
                <div class="col col-xs-5">
                <div class="product-image">
                    <div class="image"> <a href="#"> <img src="{{ asset('frontend') }}/assets/images/products/p23.jpg" alt=""> </a> </div>
                    <!-- /.image --> 
                    
                </div>
                <!-- /.product-image --> 
                </div>
                <!-- /.col -->
                <div class="col2 col-xs-7">
                <div class="product-info">
                    <h3 class="name"><a href="#">Floral Print Buttoned</a></h3>
                    <div class="rating rateit-small"></div>
                    <div class="product-price"> <span class="price"> $450.99 </span> </div>
                    <!-- /.product-price --> 
                    
                </div>
                </div>
                <!-- /.col --> 
            </div>
            <!-- /.product-micro-row --> 
            </div>
            <!-- /.product-micro --> 
            
        </div>
        </div>
    </div>
    <div class="item">
        <div class="products best-product">
        <div class="product">
            <div class="product-micro">
            <div class="row product-micro-row">
                <div class="col col-xs-5">
                <div class="product-image">
                    <div class="image"> <a href="#"> <img src="{{ asset('frontend') }}/assets/images/products/p24.jpg" alt=""> </a> </div>
                    <!-- /.image --> 
                    
                </div>
                <!-- /.product-image --> 
                </div>
                <!-- /.col -->
                <div class="col2 col-xs-7">
                <div class="product-info">
                    <h3 class="name"><a href="#">Floral Print Buttoned</a></h3>
                    <div class="rating rateit-small"></div>
                    <div class="product-price"> <span class="price"> $450.99 </span> </div>
                    <!-- /.product-price --> 
                    
                </div>
                </div>
                <!-- /.col --> 
            </div>
            <!-- /.product-micro-row --> 
            </div>
            <!-- /.product-micro --> 
            
        </div>
        <div class="product">
            <div class="product-micro">
            <div class="row product-micro-row">
                <div class="col col-xs-5">
                <div class="product-image">
                    <div class="image"> <a href="#"> <img src="{{ asset('frontend') }}/assets/images/products/p25.jpg" alt=""> </a> </div>
                    <!-- /.image --> 
                    
                </div>
                <!-- /.product-image --> 
                </div>
                <!-- /.col -->
                <div class="col2 col-xs-7">
                <div class="product-info">
                    <h3 class="name"><a href="#">Floral Print Buttoned</a></h3>
                    <div class="rating rateit-small"></div>
                    <div class="product-price"> <span class="price"> $450.99 </span> </div>
                    <!-- /.product-price --> 
                    
                </div>
                </div>
                <!-- /.col --> 
            </div>
            <!-- /.product-micro-row --> 
            </div>
            <!-- /.product-micro --> 
            
        </div>
        </div>
    </div>
    <div class="item">
        <div class="products best-product">
        <div class="product">
            <div class="product-micro">
            <div class="row product-micro-row">
                <div class="col col-xs-5">
                <div class="product-image">
                    <div class="image"> <a href="#"> <img src="{{ asset('frontend') }}/assets/images/products/p26.jpg" alt=""> </a> </div>
                    <!-- /.image --> 
                    
                </div>
                <!-- /.product-image --> 
                </div>
                <!-- /.col -->
                <div class="col2 col-xs-7">
                <div class="product-info">
                    <h3 class="name"><a href="#">Floral Print Buttoned</a></h3>
                    <div class="rating rateit-small"></div>
                    <div class="product-price"> <span class="price"> $450.99 </span> </div>
                    <!-- /.product-price --> 
                    
                </div>
                </div>
                <!-- /.col --> 
            </div>
            <!-- /.product-micro-row --> 
            </div>
            <!-- /.product-micro --> 
            
        </div>
        <div class="product">
            <div class="product-micro">
            <div class="row product-micro-row">
                <div class="col col-xs-5">
                <div class="product-image">
                    <div class="image"> <a href="#"> <img src="{{ asset('frontend') }}/assets/images/products/p27.jpg" alt=""> </a> </div>
                    <!-- /.image --> 
                    
                </div>
                <!-- /.product-image --> 
                </div>
                <!-- /.col -->
                <div class="col2 col-xs-7">
                <div class="product-info">
                    <h3 class="name"><a href="#">Floral Print Buttoned</a></h3>
                    <div class="rating rateit-small"></div>
                    <div class="product-price"> <span class="price"> $450.99 </span> </div>
                    <!-- /.product-price --> 
                    
                </div>
                </div>
                <!-- /.col --> 
            </div>
            <!-- /.product-micro-row --> 
            </div>
            <!-- /.product-micro --> 
            
        </div>
        </div>
    </div>
    </div>
</div>
<!-- /.sidebar-widget-body --> 
</div>